<?php $__env->startSection('title','سخنرانان'); ?>
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row clearfix">
                    <div class="col-md-6 col-sm-12">
                        <h1>سخنرانان</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">نوپیا</a></li>
                                <li class="breadcrumb-item active" aria-current="page">سخنرانان</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-md-6 col-sm-12 text-right hidden-xs">
                        <a href="<?php echo e(url('admin/panel/event/speaker/add/' . $event->id)); ?>" class="btn btn-sm btn-primary"
                           title="">افزودن سخنرانان</a>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="tab-content mt-0">
                            <div class="tab-pane show active" id="Users">
                                <div class="table-responsive">
                                    <table class="table table-hover table-custom spacing8">
                                        <thead>
                                        <tr>
                                            <th class="w60"></th>
                                            <th>نام</th>
                                            <th>نام خانوادگی</th>
                                            <th>سمت</th>
                                            <th>مدرک</th>
                                            <th>تاریخ ایجاد شده</th>
                                            <th class="w100">اقدام</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $speaker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="width45">
                                                    <img src="<?php echo e(url($speak->image ?? "placeholder/placeholder.png")); ?>"
                                                         data-toggle="tooltip" data-placement="top" title="نام آواتار"
                                                         alt="Avatar" class="w35 h35 rounded">
                                                </td>
                                                <td>
                                                    <h6 class="mb-0"><?php echo e($speak->name); ?></h6>
                                                </td>
                                                <td>
                                                    <h6 class="mb-0"><?php echo e($speak->family); ?></h6>
                                                </td>
                                                <td>
                                                    <h6 class="mb-0"><?php echo e($speak->post); ?></h6>
                                                </td>
                                                <td>
                                                    <?php if($speak->evidence == 0): ?>
                                                        <h6 class="mb-0">
                                                            <?php echo e('بیسواد'); ?>

                                                        </h6>
                                                    <?php endif; ?>
                                                    <?php if($speak->evidence == 1): ?>
                                                        <h6 class="mb-0">
                                                            <?php echo e('سیکل'); ?>

                                                        </h6>
                                                    <?php endif; ?>
                                                        <?php if($speak->evidence == 2): ?>
                                                            <h6 class="mb-0">
                                                                <?php echo e('حوزوی'); ?>

                                                            </h6>
                                                        <?php endif; ?>
                                                        <?php if($speak->evidence == 3): ?>
                                                            <h6 class="mb-0">
                                                                <?php echo e('دیپلم'); ?>

                                                            </h6>
                                                        <?php endif; ?>
                                                        <?php if($speak->evidence == 4): ?>
                                                            <h6 class="mb-0">
                                                                <?php echo e('فوق دیپلم'); ?>

                                                            </h6>
                                                        <?php endif; ?>
                                                        <?php if($speak->evidence == 5): ?>
                                                            <h6 class="mb-0">
                                                                <?php echo e('کارشناسی'); ?>

                                                            </h6>
                                                        <?php endif; ?>
                                                        <?php if($speak->evidence == 6): ?>
                                                            <h6 class="mb-0">
                                                                <?php echo e('کارشناسی ارشد'); ?>

                                                            </h6>
                                                        <?php endif; ?>
                                                        <?php if($speak->evidence == 7): ?>
                                                            <h6 class="mb-0">
                                                                <?php echo e('دکتری'); ?>

                                                            </h6>
                                                        <?php endif; ?>
                                                        <?php if($speak->evidence == 8): ?>
                                                            <h6 class="mb-0">
                                                                <?php echo e('فوق دکتری'); ?>

                                                            </h6>
                                                        <?php endif; ?>


                                                </td>
                                                <td>25 اسفند 1397</td>
                                                <td>
                                                    <a href="<?php echo e(url('admin/panel/event/speak/edit/' . $event->id . '/' . $speak->id)); ?>"
                                                       style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-edit"></i></a>
                                                    <a href="<?php echo e(url('admin/panel/event/speak/view/' . $event->id . '/' . $speak->id)); ?>"
                                                       style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-search"></i></a>
                                                    <a href="<?php echo e(url('admin/panel/event/speak/delete/' . $event->id . '/' . $speak->id)); ?>"
                                                       style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-trash-o text-danger"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.panel.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/event/speaker/index.blade.php ENDPATH**/ ?>