<?php $__env->startSection('title',"نمونه کارها"); ?>;
<?php $__env->startSection('content'); ?>
    <div role="main" class="main">

        <section class="page-header page-header-modern bg-color-light-scale-1 page-header-md ">
            <div class="container-fluid">
                <div class="row align-items-center">

                    <div class="col">
                        <div class="row">
                            <div class="col-md-12 align-self-center p-static order-2 text-center">
                                <div class="overflow-hidden pb-1 mb-n1">
                                    <h1 class="text-dark font-weight-bold text-9 appear-animation mt-1 mb-n2" data-appear-animation="maskUp" data-appear-animation-delay="100">نمونه کارها</h1>
                                </div>
                            </div>
                            <div class="col-md-12 align-self-center order-1">
                                <ul class="breadcrumb d-block text-center appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="300">
                                    <li><a href="/">خانه</a></li>
                                    <li><a href="<?php echo e(route('portfolio')); ?>">نمونه‌کارها</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <div class="container py-2">

            <ul class="nav nav-pills sort-source sort-source-style-3 justify-content-center" data-sort-id="portfolio" data-option-key="filter" data-plugin-options="{'layoutMode': 'fitRows', 'filter': '*'}">
                <li class="nav-item active" data-option-value="*"><a class="nav-link text-1 text-uppercase active" href="#">نمایش همه</a></li>
                <li class="nav-item" data-option-value=".websites"><a class="nav-link text-1 text-uppercase" href="#">وب‌سایت ها</a></li>
                <li class="nav-item" data-option-value=".logos"><a class="nav-link text-1 text-uppercase" href="#">لوگو ها</a></li>
                <li class="nav-item" data-option-value=".brands"><a class="nav-link text-1 text-uppercase" href="#">برند ها</a></li>
                <li class="nav-item" data-option-value=".medias"><a class="nav-link text-1 text-uppercase" href="#">رسانه ها</a></li>
            </ul>

            <div class="sort-destination-loader sort-destination-loader-showing mt-3">
                <div class="row portfolio-list sort-destination" data-sort-id="portfolio">


                    <div class="col-lg-12 isotope-item mt-4 brands">
                        <div class="row">

                            <div class="col-lg-6">
                                <div class="portfolio-item">
                                    <a href="<?php echo e(route('portfolio_single')); ?>">
												<span class="thumb-info thumb-info-no-zoom thumb-info-lighten border-radius-0 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="100">
													<span class="thumb-info-wrapper border-radius-0">
														<img src="<?php echo e(asset('site/img/projects/project-short.jpg')); ?>" class="img-fluid border-radius-0" alt="">

														<span class="thumb-info-action">
															<span class="thumb-info-action-icon bg-dark opacity-8"><i class="fas fa-plus"></i></span>
														</span>
													</span>
												</span>
                                    </a>
                                </div>
                            </div>

                            <div class="col-lg-6">

                                <div class="overflow-hidden">
                                    <h2 class="text-color-dark font-weight-bold text-5 mb-2 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="600">ارائه</h2>
                                </div>

                                <p class="appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="800">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان</p>

                                <ul class="list list-icons list-primary list-borders text-2 appear-animation mb-4" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1200">
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">مشتری:</strong> مایکروسافت</li>
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">تاریخ:</strong> خرداد 1397</li>
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">مهارت ها:</strong> <a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">طراحی</a><a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">برند</a><a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">وب‌سایت ها</a></li>
                                </ul>

                            </div>

                        </div>
                    </div>

                    <div class="col-lg-12 isotope-item mt-4 medias">
                        <div class="row">

                            <div class="col-lg-6">
                                <div class="portfolio-item">
                                    <a href="portfolio-single-wide-slider.html">
												<span class="thumb-info thumb-info-no-zoom thumb-info-lighten border-radius-0 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="100">
													<span class="thumb-info-wrapper border-radius-0">
														<span class="owl-carousel owl-theme dots-inside m-0" data-plugin-options="{'items': 1, 'margin': 20, 'animateOut': 'fadeOut', 'autoplay': true, 'autoplayTimeout': 3000}"><span>
                                                                <img src="<?php echo e(asset('site/img/projects/project-1-short.jpg')); ?>" class="img-fluid border-radius-0" alt=""></span>
                                                            <span><img src="<?php echo e(asset('site/img/projects/project-1-short-2.jpg')); ?>" class="img-fluid border-radius-0" alt=""></span></span>

														<span class="thumb-info-action">
															<span class="thumb-info-action-icon bg-dark opacity-8"><i class="fas fa-plus"></i></span>
														</span>
													</span>
												</span>
                                    </a>
                                </div>
                            </div>

                            <div class="col-lg-6">

                                <div class="overflow-hidden">
                                    <h2 class="text-color-dark font-weight-bold text-5 mb-2 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="600">ساعت پورتو</h2>
                                </div>

                                <p class="appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="800">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان</p>

                                <ul class="list list-icons list-primary list-borders text-2 appear-animation mb-4" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1200">
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">مشتری:</strong> مایکروسافت</li>
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">تاریخ:</strong> مرداد 1398</li>
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">مهارت ها:</strong> <a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">طراحی</a><a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">برند</a><a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">وب‌سایت ها</a></li>
                                </ul>

                            </div>

                        </div>
                    </div>

                    <div class="col-lg-12 isotope-item mt-4 logos">
                        <div class="row">

                            <div class="col-lg-6">
                                <div class="portfolio-item">
                                    <a href="portfolio-single-wide-slider.html">
												<span class="thumb-info thumb-info-no-zoom thumb-info-lighten border-radius-0 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="100">
													<span class="thumb-info-wrapper border-radius-0">
														<img src="<?php echo e(asset('site/img/projects/project-2-short.jpg')); ?>" class="img-fluid border-radius-0" alt="">

														<span class="thumb-info-action">
															<span class="thumb-info-action-icon bg-dark opacity-8"><i class="fas fa-plus"></i></span>
														</span>
													</span>
												</span>
                                    </a>
                                </div>
                            </div>

                            <div class="col-lg-6">

                                <div class="overflow-hidden">
                                    <h2 class="text-color-dark font-weight-bold text-5 mb-2 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="600">معرفی</h2>
                                </div>

                                <p class="appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="800">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان</p>

                                <ul class="list list-icons list-primary list-borders text-2 appear-animation mb-4" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1200">
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">مشتری:</strong> مایکروسافت</li>
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">تاریخ:</strong> مهر 1398</li>
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">مهارت ها:</strong> <a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">طراحی</a><a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">برند</a><a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">وب‌سایت ها</a></li>
                                </ul>

                            </div>

                        </div>
                    </div>

                    <div class="col-lg-12 isotope-item mt-4 websites">
                        <div class="row">

                            <div class="col-lg-6">
                                <div class="portfolio-item">
                                    <a href="portfolio-single-wide-slider.html">
												<span class="thumb-info thumb-info-no-zoom thumb-info-lighten border-radius-0 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="100">
													<span class="thumb-info-wrapper border-radius-0">
														<img src="<?php echo e(asset('site/img/projects/project-27-short.jpg')); ?>" class="img-fluid border-radius-0" alt="">

														<span class="thumb-info-action">
															<span class="thumb-info-action-icon bg-dark opacity-8"><i class="fas fa-plus"></i></span>
														</span>
													</span>
												</span>
                                    </a>
                                </div>
                            </div>

                            <div class="col-lg-6">

                                <div class="overflow-hidden">
                                    <h2 class="text-color-dark font-weight-bold text-5 mb-2 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="600">اسکرین های پورتو</h2>
                                </div>

                                <p class="appear-animation" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="800">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان</p>

                                <ul class="list list-icons list-primary list-borders text-2 appear-animation mb-4" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1200">
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">مشتری:</strong> مایکروسافت</li>
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">تاریخ:</strong> اسفند 1398</li>
                                    <li><i class="fas fa-caret-left left-10"></i> <strong class="text-color-primary">مهارت ها:</strong> <a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">طراحی</a><a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">برند</a><a href="#" class="badge badge-dark badge-sm badge-pill px-2 py-1 ml-1">وب‌سایت ها</a></li>
                                </ul>

                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/Portfolio/portfolio.blade.php ENDPATH**/ ?>