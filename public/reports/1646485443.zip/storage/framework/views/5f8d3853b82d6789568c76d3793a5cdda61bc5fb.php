<?php if(isset($last_video)): ?>
<div class="container-fluid mt-5 mb-5" style="background-color: #008080 ">
    <div class="row">
        <div class="col-12 col-md-8 p-5">
            <?php if(isset($last_video)): ?>
                <?php echo $last_video->aparat_link; ?>

            <?php endif; ?>
        </div>
        <div class="col-12 col-md-4">
            <h3 class="m-auto text-center pt-3" style="color: #fff"><?php echo e($last_video->title); ?></h3>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH /Users/hamid/Codes/nopia_new/resources/views/Home/video.blade.php ENDPATH**/ ?>