<?php $__env->startSection('title',$event->title); ?>;
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container mt-5">
            <div class="card">
                <div class="card-header"><?php echo e($event->title); ?></div>
                <div class="card-body">
                   <?php echo e($event->description); ?>

                    <hr>

                    <?php if($event->images()->count() > 0): ?>
                        <div class="row">
                            <?php $__currentLoopData = $event->images()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <div class="card">
                                        <div class="card-header"><?php echo e($image->title); ?></div>
                                        <div class="card-body">
                                            <img src="<?php echo e(url($image->path)); ?>" class="w-100 thumbnail img" alt="">
                                        </div>
                                        <div class="card-footer">
                                            <a href="<?php echo e(url('admin/event/remove_image/' . $image->id)); ?>" class="btn btn-danger">حذف</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    <?php else: ?>
                        <div class="alert alert-info">عکسی آپلود نشده است.</div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card mt-2">
                <div class="card-header">افزودن عکس همایش</div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data" action="<?php echo e(url('admin/event/add_image/' . $event->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="file">فایل عکس</label>
                            <input type="file" id="file" name="file" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="title">عنوان</label>
                            <input type="text" id="title" name="title" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="slug">نامک</label>
                            <input type="text" id="slug" name="slug" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="description">توضیحات</label>
                            <textarea id="description" name="description" class="form-control"></textarea>
                        </div>

                        <input type="submit" value="ذخیره عکس" class="btn btn-default">

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/event/view.blade.php ENDPATH**/ ?>