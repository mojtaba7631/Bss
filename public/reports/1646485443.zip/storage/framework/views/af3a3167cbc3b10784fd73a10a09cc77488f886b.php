<!doctype html>
<html lang="en">

<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description" content="Oculux Bootstrap 4x admin is super flexible, powerful, clean &amp; modern responsive admin dashboard with unlimited possibilities.">
    <meta name="keywords" content="admin template, Oculux admin template, dashboard template, flat admin template, responsive admin template, web app, Light Dark version">
    <meta name="author" content="GetBootstrap, design by: puffintheme.com">

    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <!-- VENDOR CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/animate-css/vivify.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendor/sweetalert/sweetalert.css')); ?>">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/html/site.min.css')); ?>">

</head>
<body class="theme-cyan font-montserrat light_version rtl">

<!-- Page Loader -->
<div class="page-loader-wrapper">
    <div class="loader">
        <div class="bar1"></div>
        <div class="bar2"></div>
        <div class="bar3"></div>
        <div class="bar4"></div>
        <div class="bar5"></div>
    </div>
</div>

<!-- Theme Setting -->
<div class="themesetting">
    <a href="javascript:void(0);" class="theme_btn"><i class="icon-magic-wand"></i></a>
    <div class="card theme_color">
        <div class="header">
            <h2>رنگ قالب</h2>
        </div>
        <ul class="choose-skin list-unstyled mb-0">
            <li data-theme="green"><div class="green"></div></li>
            <li data-theme="orange"><div class="orange"></div></li>
            <li data-theme="blush"><div class="blush"></div></li>
            <li data-theme="cyan" class="active"><div class="cyan"></div></li>
            <li data-theme="indigo"><div class="indigo"></div></li>
            <li data-theme="red"><div class="red"></div></li>
        </ul>
    </div>
    <div class="card font_setting">
        <div class="header">
            <h2>تنظیمات فونت</h2>
        </div>
        <div>
            <div class="fancy-radio mb-2">
                <label><input name="font" value="font-yekan" type="radio"><span><i></i>فونت یکان</span></label>
            </div>
            <div class="fancy-radio mb-2">
                <label><input name="font" value="font-iransans" type="radio" checked><span><i></i>فونت ایران سنس</span></label>
            </div>
            <div class="fancy-radio">
                <label><input name="font" value="font-shabnam" type="radio"><span><i></i>فونت شبنم</span></label>
            </div>
        </div>
    </div>
    <div class="card setting_switch">
        <div class="header">
            <h2>تنظیمات</h2>
        </div>
        <ul class="list-group">
            <li class="list-group-item">
                نسخه روشن
                <div class="float-right">
                    <label class="switch">
                        <input type="checkbox" class="lv-btn" checked="">
                        <span class="slider round"></span>
                    </label>
                </div>
            </li>
            <li class="list-group-item">
                نسخه راست چین
                <div class="float-right">
                    <label class="switch">
                        <input type="checkbox" class="rtl-btn" checked="">
                        <span class="slider round"></span>
                    </label>
                </div>
            </li>
            <li class="list-group-item">
                منو افقی
                <div class="float-right">
                    <label class="switch">
                        <input type="checkbox" class="hmenu-btn" >
                        <span class="slider round"></span>
                    </label>
                </div>
            </li>
            <li class="list-group-item">
                نوارکناری مینی
                <div class="float-right">
                    <label class="switch">
                        <input type="checkbox" class="mini-sidebar-btn">
                        <span class="slider round"></span>
                    </label>
                </div>
            </li>
        </ul>
    </div>
    <div class="card">
        <div class="form-group">
            <label class="d-block">ترافیک این ماه <span class="float-right">77%</span></label>
            <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="77" aria-valuemin="0" aria-valuemax="100" style="width: 77%;"></div>
            </div>
        </div>
        <div class="form-group">
            <label class="d-block">بارگذاری سرور <span class="float-right">50%</span></label>
            <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%;"></div>
            </div>
        </div>
    </div>
</div>

<!-- Overlay For Sidebars -->
<div class="overlay"></div>

<div id="wrapper">











































































































































    <?php echo $__env->make('admin.panel.top_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="search_div">
        <div class="card">
            <div class="body">
                <form id="navbar-search" class="navbar-form search-form">
                    <div class="input-group mb-0">
                        <input type="text" class="form-control" placeholder="جستجو...">
                        <div class="input-group-append">
                            <span class="input-group-text"><i class="icon-magnifier"></i></span>
                            <a href="javascript:void(0);" class="search_toggle btn btn-danger"><i class="icon-close"></i></a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <span>نتیجه جستجو <small class="float-right text-muted">حدود 90 نتیجه (0.47 ثانیه)</small></span>
        <div class="table-responsive">
            <table class="table table-hover table-custom spacing5">
                <tbody>
                <tr>
                    <td class="w40">
                        <span>01</span>
                    </td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="avtar-pic w35 bg-red" data-toggle="tooltip" data-placement="top" title="" data-original-title="نام آواتار"><span>SS</span></div>
                            <div class="ml-3">
                                <a href="page-invoices-detail.html" title="">آرش خادملو</a>
                                <p class="mb-0">south.shyanne@example.com</p>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <span>02</span>
                    </td>
                    <td>
                        <div class="d-flex align-items-center">
                            <img src="../assets/images/xs/avatar2.jpg" data-toggle="tooltip" data-placement="top" title="" alt="Avatar" class="w35 h35 rounded" data-original-title="نام آواتار">
                            <div class="ml-3">
                                <a href="javascript:void(0);" title="">آرش خادملو</a>
                                <p class="mb-0">zoe.baker@example.com</p>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <span>03</span>
                    </td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="avtar-pic w35 bg-indigo" data-toggle="tooltip" data-placement="top" title="" data-original-title="نام آواتار"><span>CB</span></div>
                            <div class="ml-3">
                                <a href="javascript:void(0);" title="">آرش خادملو</a>
                                <p class="mb-0">colinbrown@example.com</p>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <span>04</span>
                    </td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="avtar-pic w35 bg-green" data-toggle="tooltip" data-placement="top" title="" data-original-title="نام آواتار"><span>KG</span></div>
                            <div class="ml-3">
                                <a href="javascript:void(0);" title="">آرش خادملو</a>
                                <p class="mb-0">kevin.gill@example.com</p>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <span>05</span>
                    </td>
                    <td>
                        <div class="d-flex align-items-center">
                            <img src="../assets/images/xs/avatar5.jpg" data-toggle="tooltip" data-placement="top" title="" alt="Avatar" class="w35 h35 rounded" data-original-title="نام آواتار">
                            <div class="ml-3">
                                <a href="javascript:void(0);" title="">آرش خادملو</a>
                                <p class="mb-0">Maria.gill@example.com</p>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <span>06</span>
                    </td>
                    <td>
                        <div class="d-flex align-items-center">
                            <img src="../assets/images/xs/avatar6.jpg" data-toggle="tooltip" data-placement="top" title="" alt="Avatar" class="w35 h35 rounded" data-original-title="نام آواتار">
                            <div class="ml-3">
                                <a href="javascript:void(0);" title="">آرش خادملو</a>
                                <p class="mb-0">kevin.baker@example.com</p>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <span>07</span>
                    </td>
                    <td>
                        <div class="d-flex align-items-center">
                            <img src="../assets/images/xs/avatar2.jpg" data-toggle="tooltip" data-placement="top" title="" alt="Avatar" class="w35 h35 rounded" data-original-title="نام آواتار">
                            <div class="ml-3">
                                <a href="javascript:void(0);" title="">آرش خادملو</a>
                                <p class="mb-0">zoe.baker@example.com</p>
                            </div>
                        </div>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div id="megamenu" class="megamenu particles_js">
        <a href="javascript:void(0);" class="megamenu_toggle btn btn-danger"><i class="icon-close"></i></a>
        <div class="container">
            <div class="row clearfix">
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="card">
                        <div class="body ribbon">
                            <div class="ribbon-box green">5</div>
                            <a href="users.html" class="my_sort_cut text-muted">
                                <i class="icon-users"></i>
                                <span>کاربران</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="card">
                        <div class="body">
                            <a href="holidays.html" class="my_sort_cut text-muted">
                                <i class="icon-like"></i>
                                <span>تعطیلات</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="card">
                        <div class="body ribbon">
                            <div class="ribbon-box orange">8</div>
                            <a href="events.html" class="my_sort_cut text-muted">
                                <i class="icon-calendar"></i>
                                <span>رویدادها</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="card">
                        <div class="body">
                            <a href="payroll.html" class="my_sort_cut text-muted">
                                <i class="icon-credit-card"></i>
                                <span>لیست حقوق</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="card">
                        <div class="body">
                            <a href="accounts.html" class="my_sort_cut text-muted">
                                <i class="icon-calculator"></i>
                                <span>حساب ها</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="card">
                        <div class="body">
                            <a href="report.html" class="my_sort_cut text-muted">
                                <i class="icon-pie-chart"></i>
                                <span>گزارش</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-md-4 col-sm-12">
                    <div class="card w_card3">
                        <div class="body">
                            <div class="text-center"><i class="icon-picture text-info"></i>
                                <h4 class="m-t-25 mb-0">104 تصویر</h4>
                                <p>دانلود گالری شما کامل شده است</p>
                                <a href="javascript:void(0);" class="btn btn-info btn-round">دانلود</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="card w_card3">
                        <div class="body">
                            <div class="text-center"><i class="icon-diamond text-success"></i>
                                <h4 class="m-t-25 mb-0">813 نقطه</h4>
                                <p>شما کار خوبی انجام می دهید!</p>
                                <a href="javascript:void(0);" class="btn btn-success btn-round">خواندن</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="card w_card3">
                        <div class="body">
                            <div class="text-center"><i class="icon-social-twitter text-primary"></i>
                                <h4 class="m-t-25 mb-0">3,756</h4>
                                <p>دنبال کنندگان جدید در توییتر</p>
                                <a href="javascript:void(0);" class="btn btn-primary btn-round">بیشتر پیدا کنید</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <ul class="list-group">
                        <li class="list-group-item">
                            هر کسی یک پیام به من بفرست
                            <div class="float-right">
                                <label class="switch">
                                    <input type="checkbox" checked="">
                                    <span class="slider round"></span>
                                </label>
                            </div>
                        </li>
                        <li class="list-group-item">
                            کسی که صفحه نمایه من را ببیند
                            <div class="float-right">
                                <label class="switch">
                                    <input type="checkbox" checked="">
                                    <span class="slider round"></span>
                                </label>
                            </div>
                        </li>
                        <li class="list-group-item">
                            هر کسی نظر خود را در مورد پست من ارسال کرد
                            <div class="float-right">
                                <label class="switch">
                                    <input type="checkbox">
                                    <span class="slider round"></span>
                                </label>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="particles-js"></div>
    </div>

    <div id="rightbar" class="rightbar">
        <div class="body">
            <ul class="nav nav-tabs2">
                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#Chat-one">چت</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Chat-list">لیست</a></li>
                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Chat-groups">گروه</a></li>
            </ul>
            <hr>
            <div class="tab-content">
                <div class="tab-pane vivify fadeIn delay-100 active" id="Chat-one">
                    <div class="chat_detail">
                        <ul class="chat-widget clearfix">
                            <li class="left float-left">
                                <div class="avtar-pic w35 bg-pink"><span>KG</span></div>
                                <div class="chat-info">
                                    <span class="message">سلام، جان<br>به روز رسانی در پروژه X چیست؟</span>
                                </div>
                            </li>
                            <li class="right">
                                <img src="../assets/images/xs/avatar1.jpg" class="rounded" alt="">
                                <div class="chat-info">
                                    <span class="message">سلام، جان<br> تقریبا تکمیل شده است من امروز به شما یک ایمیل ارسال خواهم کرد.</span>
                                </div>
                            </li>
                            <li class="left float-left">
                                <div class="avtar-pic w35 bg-pink"><span>KG</span></div>
                                <div class="chat-info">
                                    <span class="message">عالیه. شما را در شب می گیرم.</span>
                                </div>
                            </li>
                            <li class="right">
                                <img src="../assets/images/xs/avatar1.jpg" class="rounded" alt="">
                                <div class="chat-info">
                                    <span class="message">مطمئنا امروز ما یک انفجار داریم.</span>
                                </div>
                            </li>
                        </ul>
                        <div class="input-group mb-0">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <a href="javascript:void(0);" class=""><i class="icon-camera text-warning"></i></a>
                                </span>
                            </div>
                            <textarea type="text" row="" class="form-control" placeholder="اینجا را وارد کنید..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="tab-pane vvivify fadeIn delay-100" id="Chat-list">
                    <ul class="right_chat list-unstyled mb-0">
                        <li class="offline">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-red"><span>FC</span></div>
                                    <div class="media-body">
                                        <span class="name">آرش خادملو</span>
                                        <span class="message">آفلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="online">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <img class="media-object " src="../assets/images/xs/avatar3.jpg" alt="">
                                    <div class="media-body">
                                        <span class="name">آرش خادملو</span>
                                        <span class="message">آنلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="online">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-red"><span>FC</span></div>
                                    <div class="media-body">
                                        <span class="name">آرش خادملو</span>
                                        <span class="message">آنلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="online">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-orange"><span>DS</span></div>
                                    <div class="media-body">
                                        <span class="name">آرش خادملو</span>
                                        <span class="message">آنلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="offline">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-green"><span>SW</span></div>
                                    <div class="media-body">
                                        <span class="name">آرش خادملو</span>
                                        <span class="message">از 12 ماه مه آفلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="online">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <img class="media-object " src="../assets/images/xs/avatar5.jpg" alt="">
                                    <div class="media-body">
                                        <span class="name">آرش خادملو</span>
                                        <span class="message">آنلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="offline">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <img class="media-object " src="../assets/images/xs/avatar2.jpg" alt="">
                                    <div class="media-body">
                                        <span class="name">آرش خادملو</span>
                                        <span class="message">از 12 ماه مه آفلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="online">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-indigo"><span>FC</span></div>
                                    <div class="media-body">
                                        <span class="name">آرش خادملو</span>
                                        <span class="message">آنلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="online">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-pink"><span>DS</span></div>
                                    <div class="media-body">
                                        <span class="name">آرش خادملو</span>
                                        <span class="message">آنلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="offline">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-info"><span>SW</span></div>
                                    <div class="media-body">
                                        <span class="name">آرش خادملو</span>
                                        <span class="message">از 12 ماه مه آفلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="tab-pane vivify fadeIn delay-100" id="Chat-groups">
                    <ul class="right_chat list-unstyled mb-0">
                        <li class="offline">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-cyan"><span>DT</span></div>
                                    <div class="media-body">
                                        <span class="name">تیم طراحیی</span>
                                        <span class="message">آفلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="online">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-azura"><span>SG</span></div>
                                    <div class="media-body">
                                        <span class="name">تیم طراحیی</span>
                                        <span class="message">آنلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="online">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-orange"><span>NF</span></div>
                                    <div class="media-body">
                                        <span class="name">تیم طراحیی</span>
                                        <span class="message">آنلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="offline">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-indigo"><span>PL</span></div>
                                    <div class="media-body">
                                        <span class="name">تیم طراحیی</span>
                                        <span class="message">از 12 ماه مه آفلاین</span>
                                        <span class="badge badge-outline status"></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div id="left-sidebar" class="sidebar">
        <div class="navbar-brand">
            <a href="index.html"><img src="../assets/images/icon.svg" alt="Oculux Logo" class="img-fluid logo"><span>اوکولوکس</span></a>
            <button type="button" class="btn-toggle-offcanvas btn btn-sm float-right"><i class="lnr lnr-menu icon-close"></i></button>
        </div>
        <div class="sidebar-scroll">
            <div class="user-account">
                <div class="user_div">
                    <img src="../assets/images/user.png" class="user-photo" alt="User Profile Picture">
                </div>
                <div class="dropdown">
                    <span>خوش آمدی،</span>
                    <a href="javascript:void(0);" class="dropdown-toggle user-name" data-toggle="dropdown"><strong>آرش خادملو</strong></a>
                    <ul class="dropdown-menu dropdown-menu-right account vivify flipInY">
                        <li><a href="profile.html"><i class="icon-user"></i>پروفایل من</a></li>
                        <li><a href="app-inbox.html"><i class="icon-envelope-open"></i>پیام ها</a></li>
                        <li><a href="javascript:void(0);"><i class="icon-settings"></i>تنظیمات</a></li>
                        <li class="divider"></li>
                        <li><a href="page-login.html"><i class="icon-power"></i>خروج</a></li>
                    </ul>
                </div>
            </div>
            <nav id="left-sidebar-nav" class="sidebar-nav">
                <ul id="main-menu" class="metismenu">
                    <li class="header">اصلی</li>
                    <li><a href="../html/index.html"><i class="icon-home"></i><span>داشبورد</span></a></li>
                    <li ><a href="index.html"><i class="icon-speedometer"></i><span>مدیریت منابع انسانی</span></a></li>
                    <li class="active open"><a href="users.html"><i class="icon-user"></i><span>کاربران</span></a></li>
                    <li><a href="departments.html"><i class="icon-grid"></i><span>بخش ها</span></a></li>
                    <li><a href="employee.html"><i class="icon-users"></i><span>کارمند</span></a></li>
                    <li><a href="activities.html"><i class="icon-equalizer"></i><span>فعالیت ها</span></a></li>
                    <li><a href="holidays.html"><i class="icon-flag"></i><span>تعطیلات</span></a></li>
                    <li><a href="events.html"><i class="icon-calendar"></i><span>رویدادها</span></a></li>
                    <li><a href="payroll.html"><i class="icon-credit-card"></i><span>لیست حقوق</span></a></li>
                    <li><a href="accounts.html"><i class="icon-wallet"></i><span>حساب ها</span></a></li>
                    <li><a href="report.html"><i class="icon-bar-chart"></i><span>گزارش</span></a></li>
                </ul>
            </nav>
        </div>
    </div>

    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row clearfix">
                    <div class="col-md-6 col-sm-12">
                        <h1>کاربران</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">اوکولوکس</a></li>
                                <li class="breadcrumb-item active" aria-current="page">کاربران</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-md-6 col-sm-12 text-right hidden-xs">
                        <a href="javascript:void(0);" class="btn btn-sm btn-primary" title="">ایجاد کمپین</a>
                        <a href="https://www.rtl-theme.com/author/paradigmshift" class="btn btn-sm btn-success" title="راست چین"><i class="icon-basket"></i> خرید قالب</a>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <ul class="nav nav-tabs">
                            <li class="nav-item"><a class="nav-link active show" data-toggle="tab" href="#Users">کاربران</a></li>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#addUser">افزودن کاربر</a></li>
                        </ul>
                        <div class="tab-content mt-0">
                            <div class="tab-pane show active" id="Users">
                                <div class="table-responsive">
                                    <table class="table table-hover table-custom spacing8">
                                        <thead>
                                        <tr>
                                            <th class="w60">نام</th>
                                            <th></th>
                                            <th></th>
                                            <th>تاریخ ایجاد شده</th>
                                            <th>نقش</th>
                                            <th class="w100">اقدام</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td class="width45">
                                                <div class="avtar-pic w35 bg-pink" data-toggle="tooltip" data-placement="top" title="نام آواتار"><span>MN</span></div>
                                            </td>
                                            <td>
                                                <h6 class="mb-0">آش خادملو</h6>
                                                <span>marshall-n@gmail.com</span>
                                            </td>
                                            <td><span class="badge badge-danger">مدیر کل</span></td>
                                            <td>25 اسفند 1397</td>
                                            <td>طراح وب</td>
                                            <td>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="../assets/images/xs/avatar5.jpg" data-toggle="tooltip" data-placement="top" title="نام آواتار" alt="Avatar" class="w35 h35 rounded">
                                            </td>
                                            <td>
                                                <h6 class="mb-0">آش خادملو</h6>
                                                <span>sussie-w@gmail.com</span>
                                            </td>
                                            <td><span class="badge badge-info">مدیر</span></td>
                                            <td>25 اسفند 1397</td>
                                            <td>طراح وب</td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-default" title="Edit"><i class="fa fa-edit"></i></button>
                                                <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="../assets/images/xs/avatar4.jpg" data-toggle="tooltip" data-placement="top" title="نام آواتار" alt="Avatar" class="w35 h35 rounded">
                                            </td>
                                            <td>
                                                <h6 class="mb-0">آش خادملو</h6>
                                                <span>debra@gmail.com</span>
                                            </td>
                                            <td><span class="badge badge-info">مدیر</span></td>
                                            <td>25 اسفند 1397</td>
                                            <td>طراح وب</td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-default" title="Edit"><i class="fa fa-edit"></i></button>
                                                <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="../assets/images/xs/avatar7.jpg" data-toggle="tooltip" data-placement="top" title="نام آواتار" alt="Avatar" class="w35 h35 rounded">
                                            </td>
                                            <td>
                                                <h6 class="mb-0">آش خادملو</h6>
                                                <span>Erinonzales@gmail.com</span>
                                            </td>
                                            <td><span class="badge badge-default">کارمند</span></td>
                                            <td>25 اسفند 1397</td>
                                            <td>طراح وب</td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-default" title="Edit"><i class="fa fa-edit"></i></button>
                                                <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="avtar-pic w35 bg-blue" data-toggle="tooltip" data-placement="top" title="نام آواتار"><span>MN</span></div>
                                            </td>
                                            <td>
                                                <h6 class="mb-0">آش خادملو</h6>
                                                <span>alexander@gmail.com</span>
                                            </td>
                                            <td><span class="badge badge-success">طراح وب مدیر</span></td>
                                            <td>25 اسفند 1397</td>
                                            <td>طراح وب</td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-default" title="Edit"><i class="fa fa-edit"></i></button>
                                                <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane" id="addUser">
                                <div class="body mt-2">
                                    <div class="row clearfix">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="نام اصلی *">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="نام خانوادگی">
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="شناسهایمیل *">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="رمز عبور">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="تایید رمز عبور">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="شماره تلفن">
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="شناسه کارمند *">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="نام کاربری *">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <select class="form-control show-tick">
                                                    <option>انتخاب نوع نقش</option>
                                                    <option>مدیر کل</option>
                                                    <option>مدیر</option>
                                                    <option>کارمند</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <h6>ماژول اجازه</h6>
                                            <div class="table-responsive">
                                                <table class="table table-striped">
                                                    <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>خاندن</th>
                                                        <th>نوشتن</th>
                                                        <th>حذف</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <tr>
                                                        <td>مدیر کل</td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>مدیر</td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>کارمند</td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>طراح وب مدیر</td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <button type="button" class="btn btn-primary">افزودن</button>
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">بستن</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Javascript -->
<script src="<?php echo e(asset('admin/assets/bundles/libscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/bundles/vendorscripts.bundle.js')); ?>"></script>

<script src="<?php echo e(asset('admin/assets/vendor/sweetalert/sweetalert.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/pages/ui/dialogs.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/users_layout.blade.php ENDPATH**/ ?>