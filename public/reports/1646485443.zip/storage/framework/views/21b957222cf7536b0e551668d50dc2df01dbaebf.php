<div id="left-sidebar" class="sidebar">
    <div class="navbar-brand">
        <a href="index.html"><img src="<?php echo e(asset('admin/assets/images/icon_g.svg')); ?>" alt="Oculux Logo" class="img-fluid logo"><span>نوپیا</span></a>
        <button type="button" class="btn-toggle-offcanvas btn btn-sm float-right"><i class="lnr lnr-menu icon-close"></i></button>
    </div>
    <div class="sidebar-scroll">
        <div class="user-account">
            <div class="user_div">
                <img src="<?php echo e(asset('admin/assets/images/user.png')); ?>" class="user-photo" alt="User Profile Picture">
            </div>
            <div class="dropdown">
                <span>خوش آمدی،</span>
                <a href="javascript:void(0);" class="dropdown-toggle user-name" data-toggle="dropdown"><strong>آرش خادملو</strong></a>
                <ul class="dropdown-menu dropdown-menu-right account vivify flipInY">
                    <li><a href="profile.html"><i class="icon-user"></i>پروفایل من</a></li>
                    <li><a href="app-inbox.html"><i class="icon-envelope-open"></i>پیام ها</a></li>
                    <li><a href="javascript:void(0);"><i class="icon-settings"></i>تنظیمات</a></li>
                    <li class="divider"></li>
                    <li><a href="page-login.html"><i class="icon-power"></i>خروج</a></li>
                </ul>
            </div>
        </div>
        <nav id="left-sidebar-nav" class="sidebar-nav">
            <ul id="main-menu" class="metismenu">
                <li class="header">اصلی</li>
                <li><a href="../html/index.html"><i class="icon-home"></i><span>داشبورد</span></a></li>
                <li ><a href="index.html"><i class="icon-speedometer"></i><span>مدیریت منابع انسانی</span></a></li>
                <li class="active open"><a href="users.html"><i class="icon-user"></i><span>کاربران</span></a></li>
                <li><a href="departments.html"><i class="icon-grid"></i><span>بخش ها</span></a></li>
                <li><a href="employee.html"><i class="icon-users"></i><span>کارمند</span></a></li>
                <li><a href="activities.html"><i class="icon-equalizer"></i><span>فعالیت ها</span></a></li>
                <li><a href="holidays.html"><i class="icon-flag"></i><span>تعطیلات</span></a></li>
                <li><a href="events.html"><i class="icon-calendar"></i><span>رویدادها</span></a></li>
                <li><a href="payroll.html"><i class="icon-credit-card"></i><span>لیست حقوق</span></a></li>
                <li><a href="accounts.html"><i class="icon-wallet"></i><span>حساب ها</span></a></li>
                <li><a href="report.html"><i class="icon-bar-chart"></i><span>گزارش</span></a></li>
            </ul>
        </nav>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/users/leftsidebar.blade.php ENDPATH**/ ?>