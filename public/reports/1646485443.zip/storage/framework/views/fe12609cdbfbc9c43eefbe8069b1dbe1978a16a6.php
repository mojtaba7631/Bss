<?php $__env->startSection('title','افزودن درباره ما'); ?>
<?php $__env->startSection('style'); ?>
    <style>
    .multiselect-container li{
        text-align: right;
    }
    .demo-card label{ display: block; position: relative;}
    .demo-card .col-lg-4{ margin-bottom: 30px;}
    </style>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h1>درباره ما</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">نوپیا</a></li>
                            <li class="breadcrumb-item active" aria-current="page">افزودن درباره ما</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-md-6 col-sm-12 text-right hidden-xs">
                    <a href="<?php echo e(url('admin/panel/about_us/')); ?>" class="btn btn-sm btn-outline-danger" title="">بازگشت به درباره ما</a>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>افزودن درباره ما</h2>
                        <ul class="header-dropdown dropdown">

                            <li><a href="javascript:void(0);" class="full-screen"><i class="icon-frame"></i></a></li>
                            <li class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"></a>
                                <ul class="dropdown-menu">
                                    <li><a href="javascript:void(0);">اقدام</a></li>
                                    <li><a href="javascript:void(0);">دیگر اقدام</a></li>
                                    <li><a href="javascript:void(0);">یک چیز دیگر</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="body wizard_validation">
                        <form id="wizard_with_validation" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <fieldset>
                                <div class="row clearfix">
                                <div class="col-12 col-md-6">
                                    <label>چشم انداز ما</label>
                                    <textarea class="summernote" name="Our_vision"></textarea>
                                </div>
                                <div class="col-12 col-md-6">
                                    <label>ماموریت ما</label>
                                    <textarea class="summernote" name="Our_mission"></textarea>
                                </div>
                                    <div class="col-12 mt-3">
                                        <label>متن درباره ما</label>
                                        <textarea class="summernote" name="description"></textarea>
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset class="mt-3">
                                <div class="row clearfix">
                                    <div class="col-md-4">
                                        <div class="header">
                                            <h2>عکس اصلی<small  style="color: red">لطفا فقط png یا jpg را آپلود کنید</small></h2>
                                        </div>
                                        <div class="body">
                                            <input type="file" name="file1" class="dropify" data-allowed-file-extensions="jpg png">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="header">
                                            <h2>عکس اول<small  style="color: red">لطفا فقط png یا jpg را آپلود کنید</small></h2>
                                        </div>
                                        <div class="body">
                                            <input type="file" name="file2" class="dropify" data-allowed-file-extensions="jpg png">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="header">
                                            <h2>عکس دوم<small  style="color: red">لطفا فقط png یا jpg را آپلود کنید</small></h2>
                                        </div>
                                        <div class="body">
                                            <input type="file" name="file3" class="dropify" data-allowed-file-extensions="jpg png">
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset class="mt-3">
                                <div class="row clearfix">
                                    <div class="col-12 col-md-3">
                                        <div class="form-group">
                                            <label>متن نوار پردازش اول</label>
                                            <input type="text" class="form-control" placeholder="متن نوار پردازش اول *" name="progress_bar_name1" required>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <div class="form-group">
                                            <label>متن نوار پردازش دوم</label>
                                            <input type="text" class="form-control" placeholder="متن نوار پردازش دوم *" name="progress_bar_name2" required>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <div class="form-group">
                                            <label>متن نوار پردازش سوم</label>
                                            <input type="text" class="form-control" placeholder="متن نوار پردازش سوم *" name="progress_bar_name3" required>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <div class="form-group">
                                            <label>متن نوار پردازش چهارم</label>
                                            <input type="text" class="form-control" placeholder="متن نوار پردازش چهارم *" name="progress_bar_name4" required>
                                        </div>
                                    </div>

                                </div>
                            </fieldset>
                            <fieldset class="mt-3">
                                <div class="row clearfix">
                                    <div class="col-12 col-md-3">
                                        <div class="form-group">
                                            <label>درصد نوار پردازش اول</label>
                                            <input type="text" class="form-control" placeholder="درصد نوار پردازش اول *" name="progress_bar_cent1" required>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <div class="form-group">
                                            <label>درصد نوار پردازش دوم</label>
                                            <input type="text" class="form-control" placeholder="درصد نوار پردازش دوم *" name="progress_bar_cent2" required>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <div class="form-group">
                                            <label>درصد نوار پردازش سوم</label>
                                            <input type="text" class="form-control" placeholder="درصد نوار پردازش سوم *" name="progress_bar_cent3" required>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-3">
                                        <div class="form-group">
                                            <label>درصد نوار پردازش چهارم</label>
                                            <input type="text" class="form-control" placeholder="درصد نوار پردازش چهارم *" name="progress_bar_cent4" required>
                                        </div>
                                    </div>

                                </div>
                            </fieldset>
                            <fieldset class="mt-3">
                                <input type="submit" class="btn btn-success" value="ثبت درباره ما">
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.panel.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/about_us/add.blade.php ENDPATH**/ ?>