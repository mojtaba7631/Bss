<?php $__env->startSection('title',$media->title); ?>;
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container mt-5">
                    <div class="card">
                        <div class="card-header" ><?php echo e($media->title); ?></div>
                        <div class="card-body" >
                            <?php echo e($media->description); ?>

                            <hr>

                            <?php if($media->images()->count() > 0): ?>
                                <div class="row">
                                    <?php $__currentLoopData = $media->images()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4">
                                            <div class="card mt-3" >
                                                <div class="card-header"><?php echo e($image->title); ?></div>
                                                <div class="card-body">
                                                    <img src="<?php echo e(url($image->path)); ?>" class="w-100 thumbnail img" alt="" style="height: 160px">
                                                </div>
                                                <div class="card-footer">
                                                    <a href="<?php echo e(url('admin/media/remove_image/' . $image->id)); ?>" class="btn btn-danger">حذف</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            <?php else: ?>
                                <div class="alert alert-info">عکسی آپلود نشده است.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card mt-2">
                        <div class="card-header">افزودن فایل رسانه</div>
                        <div class="card-body">
                            <form method="post" enctype="multipart/form-data" action="<?php echo e(url('admin/media/add_image/' . $media->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="file">فایل</label>
                                    <input type="file" id="file" name="file" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="title">عنوان</label>
                                    <input type="text" id="title" name="title" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="slug">نامک</label>
                                    <input type="text" id="slug" name="slug" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="description">توضیحات</label>
                                    <textarea id="description" name="description" class="form-control"></textarea>
                                </div>

                                <input type="submit" value="ذخیره فایل" class="btn btn-default">
                                <a href="<?php echo e(url('admin/media')); ?>" class="btn btn-default">برگشت به رسانه</a>

                            </form>
                        </div>
                    </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/media/view.blade.php ENDPATH**/ ?>