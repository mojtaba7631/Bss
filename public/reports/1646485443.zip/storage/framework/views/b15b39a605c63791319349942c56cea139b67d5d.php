<?php $__env->startSection('title',"پنل مشاهده رسانه"); ?>;
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container mt-5">
            <div class="card">
                <div class="card-header">رسانه ها</div>
                <div class="card-body">
                    <table class="table table-hover text-right table-striped">
                        <thead>
                        <tr class="text-left">
                            <td class="text-left">ردیف</td>
                            <td class="text-left">نامک</td>
                            <td class="text-left">عنوان</td>
                            <td class="text-left">توضیح</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-left">
                                <td class="text-left"><?php echo e($mass->id); ?></td>
                                <td class="text-left"><?php echo e($mass->slug); ?></td>
                                <td class="text-left"><?php echo e($mass->title); ?></td>
                                <td class="text-left"><?php echo e($mass->description); ?></td>
                                <td class="text-left">
                                    <a href="<?php echo e(url('admin/media/edit/' . $mass->id)); ?>" class="btn btn-sm btn-info">ویرایش</a>
                                    <a href="<?php echo e(url('admin/media/view/' . $mass->id)); ?>" class="btn btn-sm btn-warning">افزودن فایل</a>
                                    <a href="<?php echo e(url('admin/media/delete/' . $mass->id)); ?>" class="btn btn-sm btn-danger">حذف</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <a href="<?php echo e(url('admin/media/add/')); ?>" class="btn btn-sm btn-success">اضافه کردن رسانه</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/media/index.blade.php ENDPATH**/ ?>