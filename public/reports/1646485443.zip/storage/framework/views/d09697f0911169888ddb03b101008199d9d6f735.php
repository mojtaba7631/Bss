<div id="megamenu" class="megamenu particles_js">
    <a href="javascript:void(0);" class="megamenu_toggle btn btn-danger"><i class="icon-close"></i></a>
    <div class="container">
        <div class="row clearfix">
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body ribbon">
                        <div class="ribbon-box green">5</div>
                        <a href="users.html" class="my_sort_cut text-muted">
                            <i class="icon-users"></i>
                            <span>کاربران</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body">
                        <a href="holidays.html" class="my_sort_cut text-muted">
                            <i class="icon-like"></i>
                            <span>تعطیلات</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body ribbon">
                        <div class="ribbon-box orange">8</div>
                        <a href="events.html" class="my_sort_cut text-muted">
                            <i class="icon-calendar"></i>
                            <span>رویدادها</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body">
                        <a href="payroll.html" class="my_sort_cut text-muted">
                            <i class="icon-credit-card"></i>
                            <span>لیست حقوق</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body">
                        <a href="accounts.html" class="my_sort_cut text-muted">
                            <i class="icon-calculator"></i>
                            <span>حساب ها</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-4 col-xl-2">
                <div class="card">
                    <div class="body">
                        <a href="report.html" class="my_sort_cut text-muted">
                            <i class="icon-pie-chart"></i>
                            <span>گزارش</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-md-4 col-sm-12">
                <div class="card w_card3">
                    <div class="body">
                        <div class="text-center"><i class="icon-picture text-info"></i>
                            <h4 class="m-t-25 mb-0">104 تصویر</h4>
                            <p>دانلود گالری شما کامل شده است</p>
                            <a href="javascript:void(0);" class="btn btn-info btn-round">دانلود</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card w_card3">
                    <div class="body">
                        <div class="text-center"><i class="icon-diamond text-success"></i>
                            <h4 class="m-t-25 mb-0">813 نقطه</h4>
                            <p>شما کار خوبی انجام می دهید!</p>
                            <a href="javascript:void(0);" class="btn btn-success btn-round">خواندن</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card w_card3">
                    <div class="body">
                        <div class="text-center"><i class="icon-social-twitter text-primary"></i>
                            <h4 class="m-t-25 mb-0">3,756</h4>
                            <p>دنبال کنندگان جدید در توییتر</p>
                            <a href="javascript:void(0);" class="btn btn-primary btn-round">بیشتر پیدا کنید</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <ul class="list-group">
                    <li class="list-group-item">
                        هر کسی یک پیام به من بفرست
                        <div class="float-right">
                            <label class="switch">
                                <input type="checkbox" checked="">
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </li>
                    <li class="list-group-item">
                        کسی که صفحه نمایه من را ببیند
                        <div class="float-right">
                            <label class="switch">
                                <input type="checkbox" checked="">
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </li>
                    <li class="list-group-item">
                        هر کسی نظر خود را در مورد پست من ارسال کرد
                        <div class="float-right">
                            <label class="switch">
                                <input type="checkbox">
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div id="particles-js"></div>
</div>
<?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/users/megamenu.blade.php ENDPATH**/ ?>