<?php $__env->startSection('title',"ویرایش تنظیمات"); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <div class="card">
                <div class="card-header">اضافه کردن تنظیمات</div>
                <div class="card-body">
                    <form method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="tell1">تلفن اول</label>
                                    <input type="text" id="tell1" value="<?php echo e($settings->tell1); ?>" name="tell1" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="tell2">تلفن دوم</label>
                                    <input type="text" id="tell2" value="<?php echo e($settings->tell2); ?>" name="tell2" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="email">ایمیل</label>
                                    <input type="text" id="email" value="<?php echo e($settings->email); ?>" name="email" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="map">نقشه</label>
                                    <input type="text" id="map" name="map" class="form-control" value="<?php echo e($settings->map); ?>">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="description">آدرس</label>
                                    <textarea name="description" id="description" class="form-control"><?php echo e($settings->address); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-success">ثبت تنظیمات</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/settings/edit.blade.php ENDPATH**/ ?>