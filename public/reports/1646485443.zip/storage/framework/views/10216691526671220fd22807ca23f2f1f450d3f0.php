<?php $__env->startSection('title',"پنل مشاهده تنظیمات"); ?>;
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">تنظیمات</div>
            <div class="card-body">
            <table class="table table-hover text-right table-striped">
                <thead>
                <tr class="text-left">
                    <td class="text-left">ردیف</td>
                    <td class="text-left">تلفن اول</td>
                    <td class="text-left">تلفن دوم</td>
                    <td class="text-left">ایمیل</td>
                    <td class="text-left">نقشه</td>
                    <td class="text-left">آدرس</td>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-left">
                        <td class="text-left"><?php echo e($setting->id); ?></td>
                        <td class="text-left"><?php echo e($setting->tell1); ?></td>
                        <td class="text-left"><?php echo e($setting->tell2); ?></td>
                        <td class="text-left"><?php echo e($setting->email); ?></td>
                        <td class="text-left"><?php echo e($setting->map); ?></td>
                        <td class="text-left"><?php echo e($setting->address); ?></td>
                        <td class="text-left">
                            <a href="<?php echo e(url('admin/settings/edit/' . $setting->id)); ?>" class="btn btn-sm btn-info">ویرایش</a>
                            <a href="<?php echo e(url('admin/settings/delete/' . $setting->id)); ?>" class="btn btn-sm btn-danger">حذف</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
        </div>
        <a href="<?php echo e(url('admin/settings/add/')); ?>" class="btn btn-sm btn-success">اضافه کردن تنظیم</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>