<?php $__env->startSection('title',"ورود / ثبت نام"); ?>
<?php $__env->startSection('content'); ?>
    <style>
        @media  screen and (max-width: 960px)
        {
            .wrap-left4
            {
                width: 100% !important;
            }
        }
        .btn_save{
            background: #daa520;
            padding: 8px 37px 8px 37px;
            border-radius: 5px;
            color: #fff !important;
            margin: 0 auto;
            text-align: center;
            display: table;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
        }
        #first_step, #second_step {
            display: flex;
        }
        .right_back{
            background: #008080;
            float: right;
            border-top-right-radius: 15px;
            border-bottom-right-radius: 15px
        }
        .reright_back{
            background: #008080;
            /* float: right; */
            border-top-right-radius: 15px;
            border-bottom-right-radius: 15px;
            /* height: 362px; */
        }
        .left_back{
            /* float: right; */
            border-top-left-radius: 15px;
            border-bottom-left-radius: 15px;
            /* height:362px; */
            background-color: #fff;
        }
        .sp{
            color: #000;
            width: 100%;
            text-align: center;
            display: block;
            font-size: 16px;
        }
        .txt_mobile{
            width: 100%;
            border: 1px solid #f5f8f9;
            color: #74787b !important;
            border-radius: 5px;
            background-color: #f5f8f9;
            text-align: center  ;
        }
        .forget_h6{
            display: block;
            text-align: center;
            color:#74787b;
            size: 12px !important;
        }
        .main_con{
            width: 700px;border-radius: 15px
        }
        .main_row{
            background-image: url('<?php echo e("site/img/slides/slide-bg-6.jpg"); ?>');
        }
        .if_h5{
            color: #fff;
        }
        .inp{
            border:0 !important;
        }
    </style>
    <section class="page-header page-header-classic">
        <div class="container">
            <div class="row">
                <div class="col-md-4 order-1 order-md-2 align-self-center">
                    <h1 class="mb-n2 mb-md-0">ثبت نام</h1>

                </div>
                <div class="col-md-8 order-2 order-md-1 align-self-center p-static">
                    <ul class="breadcrumb d-block text-md-left breadcrumb-light mb-1 mb-md-0">
                        <li><a href="/">خانه</a></li>
                        <li class="active">ورود / ثبت نام</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(\Illuminate\Support\Facades\Session::has('success_msg')): ?>
            <div class="alert alert-success">
                <?php echo e(\Illuminate\Support\Facades\Session::get('success_msg')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="row main_row">

        <div class="container mt-5 mb-5 wrap-left4 main_con">

            <div id="first_step">
                <div class="col-12 col-md-5 mt-2 right_back">
                    <div style="width: 100%;text-align: center;margin-top: 100px">
                        <img style="width:50%" src="<?php echo e(asset('site/img/nopia_logo.png')); ?>" alt="">
                        <h5 class="mt-2 if_h5">اگر عضو هستید لطفا وارد شوید</h5>
                        <a href="<?php echo e(route('login')); ?>" class="btn_save mb-5">واردشوید </a>
                    </div>
                </div>

                <div class="col-12 col-md-7 mt-2 left_back">
                    <span class="sp mt-3"> ورود به رویداد نوپیا </span>

                    <input type="text" name="name" class="mt-3 txt_mobile" placeholder="لطفا نام خود را وارد کنید" value="<?php echo e(old('name')); ?>" id="name">
                    <div id="name_errors" class="text-danger"></div>

                    <input type="text" name="family" class="mt-1 txt_mobile" placeholder="لطفا نام خانوادگی خود را وارد کنید" value="<?php echo e(old('family')); ?>" id="family">
                    <div id="family_errors" class="text-danger"></div>


                    <input type="text" name="id_code" class="mt-1 txt_mobile" placeholder="لطفا کدملی خود را وارد کنید" value="<?php echo e(old('id_code')); ?>" id="id_code">
                    <div id="id_code_errors" class="text-danger"></div>

                    <input type="text" name="mobile" class="mt-1 txt_mobile" placeholder="لطفا موبایل خود را وارد کنید" value="<?php echo e(old('mobile')); ?>" id="mobile">
                    <div id="mobile_errors" class="text-danger"></div>


                    <div class="questions mt-2">
                        <div class="form-group">
                            <label for="type">نحوه حضور شما در رویداد؟</label>
                            <select name="type" id="type" class="form-control">
                                <option value="0">مجازی</option>
                                <option value="1">حضوری</option>
                            </select>
                        </div>

                        <div id="no_section">
                            <div class="form-group">
                                <label for="net">اگر شماره ی فضای مجازی دارید وارد کنید.</label>
                                <input type="text" id="net" name="net" class="form-control ltr">
                            </div>
                        </div>

                        <div id="yes_section" style="display: none;">
                            <div class="form-group">
                                <label for="ghorfe">آیا نیاز به غرفه دارید؟</label>
                                <select name="ghorfe" id="ghorfe" class="form-control">
                                    <option value="0">خیر</option>
                                    <option value="1">بله</option>
                                </select>
                            </div>
        
                            <div class="form-group">
                                <label for="panel">آیا نیاز به پنل دارید؟</label>
                                <select name="panel" id="panel" class="form-control">
                                    <option value="0">خیر</option>
                                    <option value="1">بله</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" id="submit" class="btn_save mt-5 inp" >ثبت نام</button>
                    <a href="<?php echo e(route('site')); ?>" class="forget_h6 mt-5">بازگشت به سایت</a>
                </div>
            </div>
            <div id="second_step" style="display: none">
                <div class="col-12 col-md-5 mt-2 right_back">
                    <div style="width: 100%;text-align: center;margin-top: 100px">
                        <img style="width:50%" src="<?php echo e(asset('site/img/nopia_logo.png')); ?>" alt="">
                        <h5 class="mt-2 if_h5">اگر عضو هستید لطفا وارد شوید</h5>
                        <a href="<?php echo e(route('login')); ?>" class="btn_save mb-5">واردشوید </a>
                    </div>
                </div>

                <div class="col-12 col-md-7 mt-2 left_back">
                    <span class="sp mt-5"> ورود به رویداد نوپیا </span>
                    <input type="number" name="otp" class="mt-5 txt_mobile" placeholder="لطفا کد ارسال شده را وارد کنید"  id="otp" value="">
                    <button type="submit" id="submit_otp" class="btn_save mt-5 inp" >ورود</button>
                    <a href="<?php echo e(route('site')); ?>" class="forget_h6 mt-5">بازگشت به سایت</a>
                </div>
            </div>

        </div>

            <div class="message" id="message">

            </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        let id = 0;

        let _token = "<?php echo e(csrf_token()); ?>";
        $('#submit').click(function () {
            let name    = $('#name').val();
            let family  = $('#family').val();
            let id_code = $('#id_code').val();
            let mobile  = $('#mobile').val();
            let type = $("#type").val();
            let ghorfe = $("#ghorfe").val();
            let panel = $("#panel").val();

            console.log(type, ghorfe)
            $.post("<?php echo e(url('register')); ?>",{
                    "_token"    : _token,
                    'name'     : name ,
                    'family'   : family ,
                    'id_code'  : id_code ,
                    'mobile'   : mobile,
                    'type': type, 
                    'ghorfe': ghorfe,
                    'panel': panel
                },
                function (response){
                    
                    if(response.status === true){
                        $('#first_step').hide();
                        $('#second_step').fadeIn();
                        // $('#message').text(response.message);
                        alert(response.message);
                        id = response.id;
                        step = 'second'
                    }
                    else {
                        alert(response.message);

                        for (let field in response.errors){
                            let errors = response.errors[field]
                            for (let error of errors) {
                                console.log(field, error)
                                $('#' + field + '_errors').html("<p style='color: red;'>" + error + "</p>");
                            }
                        }

                        
                    }
                        

                });
            });
        // }
        //     else if (step === 'second'){
        $("#submit_otp").click(function () {
            console.log('sub_otp');
            let otp = $('#otp').val();
            $.post("<?php echo e(url('verify')); ?>",{
                _token, otp, id
                },
                function (response){
                    // console.log(response);
                    alert(response.message);
                    if(response.status === true){
                        window.location = "<?php echo e(url('panel')); ?>"
                    }
                });
        });

        $("#type").change(function () {
            let type = $("#type").val();
            if (type === "0") {
                $("#yes_section").hide();
                $("#no_section").fadeIn();
            } else {
                $("#yes_section").fadeIn();
                $("#no_section").hide();
            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/hamid/Codes/nopia_new/resources/views/auth/register.blade.php ENDPATH**/ ?>