<?php $__env->startSection('title',"پنل اضافه کردن اخبار"); ?>
<?php $__env->startSection('content'); ?>
    <div role="main" class="main">

        <section class="page-header page-header-classic">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 order-1 order-md-2 align-self-center">
                        <h1 class="mb-n2 mb-md-0">ثبت نام</h1>

                    </div>
                    <div class="col-md-8 order-2 order-md-1 align-self-center p-static">
                        <ul class="breadcrumb d-block text-md-left breadcrumb-light mb-1 mb-md-0">
                            <li><a href="/">خانه</a></li>
                            <li class="active">ورود / ثبت نام</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <div class="container mt-5">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(\Illuminate\Support\Facades\Session::has('success_msg')): ?>
                <div class="alert alert-success">
                    <?php echo e(\Illuminate\Support\Facades\Session::get('success_msg')); ?>

                </div>
            <?php endif; ?>
        </div>

        <div class="container">

            <div class="row">
                <div class="col">
                    <div class="featured-boxes">
                        <div class="row">
                            <div class="col-md-3"></div>
                            <div class="col-md-6">
                                <div id="first_step">
                                    <div class="featured-box featured-box-primary text-left mt-1">
                                        <div class="box-content">
                                            <h4 class="color-primary font-weight-semibold text-4 text-uppercase mb-3">ثبت در نوپیا</h4>
                                            
                                            
                                            <div class="form-row">
                                                <div class="form-group col-lg-12">
                                                    
                                                    <input type="text" value="<?php echo e(old('name')); ?>" id="name" placeholder="نام خود را وارد کنید" name="name" class="form-control form-control-lg text-left" dir="ltr" >
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    
                                                    <input type="text" value="<?php echo e(old('family')); ?>" id="family" placeholder="نام خانوادگی خود را وارد کنید" name="family" class="form-control form-control-lg text-left" dir="ltr" >
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-lg-12">
                                                    
                                                    <input type="text" value="<?php echo e(old('id_code')); ?>" id="id_code" placeholder="کدملی خود را وارد کنید" name="id_code" class="form-control form-control-lg text-left" dir="ltr" >
                                                </div>
                                                <div class="form-group col-lg-12">
                                                    
                                                    <input type="text" value="<?php echo e(old('mobile')); ?>" id="mobile" placeholder="تلفن همراه خود را وارد کنید" name="mobile" class="form-control form-control-lg text-left" dir="ltr" >
                                                </div>
                                            </div>
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            <div class="form-row">
                                                <div class="form-group col-lg-9">
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input" id="terms">
                                                        <label class="custom-control-label text-2" for="terms" style="color: #fff">من <a href="#">قوانین و مقررات</a> را خوانده و موافقم</label>
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-3">
                                                    <button id="submit" type="submit" class="btn btn-primary btn-modern float-right"
                                                            data-loading-text="در حال بارگذاری ..."> ثبت نام </button>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div id="second_step" style="display: none">
                                    <div class="featured-box featured-box-primary text-left mt-1">
                                        <div class="box-content">
                                            <h4 class="color-primary font-weight-semibold text-4 text-uppercase mb-3">به نوپیا خوش آمدید</h4>
                                            
                                            
                                            <div class="form-row">
                                                <div class="form-group col">
                                                    <label for="otp" class="font-weight-bold text-dark text-2" style="color:#fff !important;">کد ارسال شده</label>
                                                    <input type="number" name="otp" id="otp" value="" class="form-control form-control-lg text-left" dir="ltr">
                                                </div>
                                            </div>

                                            
                                            

                                            
                                            
                                            
                                            
                                            <div class="form-row">
                                                <div class="form-group col-lg-6">


                                                    
                                                    
                                                    
                                                    
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    
                                                    
                                                    <button id="submit_otp" class="btn btn-success">ورود</button>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="message" id="message">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/new/test.blade.php ENDPATH**/ ?>