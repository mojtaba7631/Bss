<?php $__env->startSection('title',"پنل مشاهده رویداد"); ?>;
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container mt-5">
            <div class="card">
                <div class="card-header">رویداد ها</div>
                <div class="card-body">
                    <table class="table table-hover text-right table-striped">
                        <thead>
                        <tr class="text-left">
                            <td class="text-left">ردیف</td>
                            <td class="text-left">نامک رویداد</td>
                            <td class="text-left">عنوان رویداد</td>
                            <td class="text-left">توضیح رویداد</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-left">
                                <td class="text-left"><?php echo e($event->id); ?></td>
                                <td class="text-left"><?php echo e($event->slug); ?></td>
                                <td class="text-left"><?php echo e($event->title); ?></td>
                                <td class="text-left"><?php echo e($event->description); ?></td>
                                <td class="text-left">
                                    <a href="<?php echo e(url('admin/event/edit/' . $event->id)); ?>" class="btn btn-sm btn-info">ویرایش</a>
                                    <a href="<?php echo e(url('admin/event/delete/' . $event->id)); ?>" class="btn btn-sm btn-danger">حذف</a>
                                    <a href="<?php echo e(url('admin/event/view/' . $event->id)); ?>" class="btn btn-sm btn-success">مشاهده</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <a href="<?php echo e(url('admin/event/add/')); ?>" class="btn btn-sm btn-success">اضافه کردن رویداد</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/event/index.blade.php ENDPATH**/ ?>