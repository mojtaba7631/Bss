<?php $__env->startSection('title',"ویرایش مدیا"); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <div class="card">
                <div class="card-header">ویرایش مدیا</div>
                <div class="card-body">
                    <form method="post">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="title">عنوان</label>
                                    <input type="text" id="title" value="<?php echo e($media->title); ?>" name="title" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="url">نامک</label>
                                    <input type="text" id="url" value="<?php echo e($media->slug); ?>" name="url" class="form-control">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="description">توضیحات</label>
                                    <textarea name="description" id="description" class="form-control">
                                        <?php echo e($media->description); ?>

                                    </textarea>
                                </div>
                            </div>
                        </div>




                        <hr>
                        <button type="submit" class="btn btn-success">ثبت مدیا</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/media/edit.blade.php ENDPATH**/ ?>