<?php $__env->startSection('title',"پنل اضافه کردن رسانه"); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <div class="card">
                <div class="card-header">اضافه کردن رسانه</div>
                <div class="card-body">
                    <form method="post">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="title">عنوان</label>
                                    <input type="text" id="title" name="title" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="url">نامک</label>
                                    <input type="text" id="url" name="url" class="form-control">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="description">توضیح رویداد</label>
                                    <textarea name="description" id="description" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-success">ثبت رویداد</button>
                        <a href="<?php echo e(url('admin/media')); ?>" class="btn btn-sm btn-gradient">بازگشت به رویدادها</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/media/add.blade.php ENDPATH**/ ?>