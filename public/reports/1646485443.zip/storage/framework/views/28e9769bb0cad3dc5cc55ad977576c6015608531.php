<?php $__env->startSection('title',"ورود"); ?>;
<?php $__env->startSection('content'); ?>
    <style>
        @media  screen and (max-width: 960px)
        {
            .wrap-left4
            {
                width: 100% !important;
            }
        }
        .btn_save{
            background: #daa520;
            padding: 8px 37px 8px 37px;
            border-radius: 5px;
            color: #fff !important;
            margin: 0 auto;
            text-align: center;
            display: table;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
        }
        .right_back{
            background: #008080;
            float: right;
            border-top-right-radius: 15px;
            border-bottom-right-radius: 15px
        }
        .left_back{
            float: right;
            border-top-left-radius: 15px;
            border-bottom-left-radius: 15px;
            height:363px;
            background-color: #fff;
        }
        .sp{
            color: #000;
            width: 100%;
            text-align: center;
            display: block;
            font-size: 16px;
        }
        .txt_mobile{
            width: 100%;
            border: 1px solid #f5f8f9;
            color: #74787b !important;
            border-radius: 5px;
            background-color: #f5f8f9;
            text-align: center  ;
        }
        .forget_h6{
            display: block;
            text-align: center;
            color:#74787b;
            size: 12px !important;
        }
        .main_con{
            width: 700px;border-radius: 15px
        }
        .main_row{
            background-image: url('<?php echo e("site/img/slides/slide-bg-6.jpg"); ?>');
        }
        .if_h5{
            color: #fff;
        }
        .inp{
            border:0 !important;
        }
    </style>

    <section class="page-header page-header-classic">
        <div class="container">
            <div class="row">
                <div class="col-md-4 order-1 order-md-2 align-self-center">
                    <h1 class="mb-n2 mb-md-0">ورود به سیستم</h1>
                </div>
                <div class="col-md-8 order-2 order-md-1 align-self-center p-static">
                    <ul class="breadcrumb d-block text-md-left breadcrumb-light mb-1 mb-md-0">
                        <li><a href="/">خانه</a></li>
                        <li class="active">ورود / ثبت نام</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(\Illuminate\Support\Facades\Session::has('success_msg')): ?>
            <div class="alert alert-success">
                <?php echo e(\Illuminate\Support\Facades\Session::get('success_msg')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="row main_row">

        <div class="container mt-5 mb-5 wrap-left4 main_con">

            <div class="col-12 col-md-5 mt-2 right_back">

                <div style="width: 100%;text-align: center;margin-top: 100px">
                    <img style="width:50%" src="<?php echo e(asset('site/img/nopia_logo.png')); ?>" alt="">
                    <h5 class="mt-2 if_h5">اگر عضو نیستید لطفا ثبت نام کنید</h5>
                    <a href="<?php echo e(route('register')); ?>" class="btn_save mb-5">ثبت نام </a>
                </div>

                <div class=""></div>
            </div>

            <div class="col-12 col-md-7 mt-2 left_back">
                <span class="sp mt-5"> ورود به رویداد نوپیا </span>
                <input type="text" class="mt-5 txt_mobile" placeholder="لطفا شماره موبایل خود را وارد کنید">
                <input type="submit" class="btn_save mt-5 inp" value="ورود">
                <a href="#" class="forget_h6 mt-5">رمز عبور خود را فراموش کرده اید</a>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/hamid/Codes/nopia_new/resources/views/auth/login.blade.php ENDPATH**/ ?>