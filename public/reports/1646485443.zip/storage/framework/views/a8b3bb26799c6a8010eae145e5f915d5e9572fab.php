<?php $__env->startSection('title','ویرایش مدیا'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .multiselect-container li{
            text-align: right;
        }
        .demo-card label{ display: block; position: relative;}
        .demo-card .col-lg-4{ margin-bottom: 30px;}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h1>مدیا</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">نوپیا</a></li>
                            <li class="breadcrumb-item active" aria-current="page">ویرایش مدیا</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-md-6 col-sm-12 text-right hidden-xs">
                    <a href="<?php echo e(url('admin/panel/new/')); ?>" class="btn btn-sm btn-outline-danger" title="">بازگشت به مدیا</a>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>ویرایش مدیا</h2>
                        <ul class="header-dropdown dropdown">

                            <li><a href="javascript:void(0);" class="full-screen"><i class="icon-frame"></i></a></li>
                            <li class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"></a>
                                <ul class="dropdown-menu">
                                    <li><a href="javascript:void(0);">اقدام</a></li>
                                    <li><a href="javascript:void(0);">دیگر اقدام</a></li>
                                    <li><a href="javascript:void(0);">یک چیز دیگر</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="body wizard_validation">
                        <form id="wizard_with_validation" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <fieldset>
                                <div class="row clearfix">
                                    <div class="col-lg-4 col-md-12">
                                        <div class="form-group">
                                            <label>عنوان</label>
                                            <input type="text" value="<?php echo e($media->title); ?>" class="form-control" placeholder="عنوان *" name="title" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                        <div class="form-group">
                                            <label>نامک</label>
                                            <input type="text" value="<?php echo e($media->slug); ?>" class="form-control" placeholder="نامک *" name="slug" id="slug" required>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset>
                                <div class="row clearfix">
                                    <div class="col-md-8">
                                        <label>توضیحات مدیا</label>
                                        <textarea class="summernote" name="description"><?php echo e($media->description); ?></textarea>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="header">
                                            <h2>محدودیت فایل<small  style="color: red">لطفا فقط png یا jpg را آپلود کنید</small></h2>
                                        </div>
                                        <div class="body">
                                            <input type="file" name="file" class="dropify" data-allowed-file-extensions="jpg png">
                                        </div>
                                        <label class="mt-3">نامک</label>
                                        <div class="form-group">
                                            <input type="text" value="<?php echo e($media->slug); ?>" name="slug" placeholder="نامک *" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <label>برچسب ها</label>
                                        <div class="input-group demo-tagsinput-area">
                                            <input name="tags" type="text" class="form-control" data-role="tagsinput" value="نوآوری,خدمات,وحدت">
                                        </div>
                                    </div>

                                    <div>
                                        <input type="submit" class="btn btn-success" value="ثبت تغییرات">
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.panel.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/media/edit.blade.php ENDPATH**/ ?>