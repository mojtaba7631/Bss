<!-- Vendor CSS -->
<link rel="stylesheet" href="<?php echo e(asset('site/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/vendor/fontawesome-free/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/vendor/animate/animate.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/vendor/simple-line-icons/css/simple-line-icons.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/vendor/owl.carousel/assets/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/vendor/owl.carousel/assets/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/vendor/magnific-popup/magnific-popup.min.css')); ?>">

<!-- Theme CSS -->
<link rel="stylesheet" href="<?php echo e(asset('site/css/theme.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/css/theme-elements.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/css/theme-blog.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('site/css/theme-shop.css')); ?>">


<!-- Demo CSS -->


<!-- Skin CSS -->
<link rel="stylesheet" href="<?php echo e(asset('site/css/skins/default.css')); ?>">

<!-- Theme Custom CSS -->
<link rel="stylesheet" href="<?php echo e(asset('site/css/custom.css')); ?>">

<!-- Head Libs -->
<script src="<?php echo e(asset('site/vendor/modernizr/modernizr.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\nopia\resources\views/css_js/styles.blade.php ENDPATH**/ ?>