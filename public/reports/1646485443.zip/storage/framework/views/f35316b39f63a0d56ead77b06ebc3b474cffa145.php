<?php $__env->startSection('title',"پنل مشاهده اخبار"); ?>;
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="container mt-5">
        <div class="card">
            <div class="card-header">خبر</div>
            <div class="card-body">
            <table class="table table-hover text-right table-striped">
                <thead>
                <tr class="text-left">
                    <td class="text-left">ردیف</td>
                    <td class="text-left">نامک</td>
                    <td class="text-left">عنوان</td>
                    <td class="text-left">وضعیت</td>
                    <td class="text-left">دسته بندی</td>
                    <td class="text-left">برچسب ها</td>
                    <td class="text-left">عملیات</td>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-left">
                        <td class="text-left"><?php echo e($new->id); ?></td>
                        <td class="text-left"><?php echo e($new->slug); ?></td>
                        <td class="text-left"><?php echo e($new->title); ?></td>
                        <td class="text-left"><?php echo e($new->status == 0  ? "پیش نویس" : "منتشرشده"); ?></td>
                        <td class="text-left">
                            <?php $__currentLoopData = $new->categories()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-success"><?php echo e($category->title); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td class="text-left">
                            <?php $__currentLoopData = $new->tags()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-success"><?php echo e($tag->title); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td class="text-left">
                            <a href="<?php echo e(url('admin/new/edit/' . $new->id)); ?>" class="btn btn-sm btn-info">ویرایش</a>
                            <a href="<?php echo e(url('admin/new/delete/' . $new->id)); ?>" class="btn btn-sm btn-danger">حذف</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
        </div>
        <a href="<?php echo e(url('admin/new/add/')); ?>" class="btn btn-sm btn-success">اضافه کردن خبر</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/new/index.blade.php ENDPATH**/ ?>