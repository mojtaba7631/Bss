<nav class="navbar top-navbar">
    <div class="container-fluid">

        <div class="navbar-left">
            <div class="navbar-btn">
                <a href="index.html"><img src="<?php echo e(asset('admin/assets/images/icon_g.svg')); ?>" alt="Oculux Logo" class="img-fluid logo"></a>
                <button type="button" class="btn-toggle-offcanvas"><i class="lnr lnr-menu fa fa-bars"></i></button>
            </div>
            <ul class="nav navbar-nav">
                <li class="dropdown">
                    <a href="javascript:void(0);" class="dropdown-toggle icon-menu" data-toggle="dropdown">
                        <i class="icon-envelope"></i>
                        <span class="notification-dot bg-green">4</span>
                    </a>
                    <ul class="dropdown-menu right_chat email vivify fadeIn">
                        <li class="header green">شما 4 ایمیل جدید دارید</li>
                        <li>
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-red"><span>FC</span></div>
                                    <div class="media-body">
                                        <span class="name">آرش خادملو <small class="float-right text-muted">همین حالا</small></span>
                                        <span class="message">بروزرسانی گیتهاب</span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <div class="avtar-pic w35 bg-indigo"><span>FC</span></div>
                                    <div class="media-body">
                                        <span class="name">آرش خادملو <small class="float-right text-muted">12 دقیقه پیش</small></span>
                                        <span class="message">پیام های جدید</span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <img class="media-object " src="<?php echo e(asset('admin/assets/images/xs/avatar5.jpg')); ?>" alt="">
                                    <div class="media-body">
                                        <span class="name">آرش خادملو <small class="float-right text-muted">38 دقیقه پیش</small></span>
                                        <span class="message">رفع اشکال طراحی</span>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <div class="media mb-0">
                                    <img class="media-object " src="<?php echo e(asset('admin/assets/images/xs/avatar2.jpg')); ?>" alt="">
                                    <div class="media-body">
                                        <span class="name">آرش خادملو <small class="float-right text-muted">12 دقیقه پیش</small></span>
                                        <span class="message">رفع اشکال</span>
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="javascript:void(0);" class="dropdown-toggle icon-menu" data-toggle="dropdown">
                        <i class="icon-bell"></i>
                        <span class="notification-dot bg-azura">4</span>
                    </a>
                    <ul class="dropdown-menu feeds_widget vivify fadeIn">
                        <li class="header blue">شما 4 اطلاعیه جدید دارید</li>
                        <li>
                            <a href="javascript:void(0);">
                                <div class="feeds-left bg-red"><i class="fa fa-check"></i></div>
                                <div class="feeds-body">
                                    <h4 class="title text-danger">شماره ثابت <small class="float-right text-muted">9:10 صبح</small></h4>
                                    <small>ما همه اشکال طراحی با پاسخگو را رفع کرده ایم</small>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <div class="feeds-left bg-info"><i class="fa fa-user"></i></div>
                                <div class="feeds-body">
                                    <h4 class="title text-info">کاربر جدید <small class="float-right text-muted">9:10 صبح</small></h4>
                                    <small>حس خوبی دارم توپ توپم! با تشکر از تیم</small>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <div class="feeds-left bg-orange"><i class="fa fa-question-circle"></i></div>
                                <div class="feeds-body">
                                    <h4 class="title text-warning">هشدار سرور <small class="float-right text-muted">9:10 صبح</small></h4>
                                    <small>اتصال شما خصوصی نیست</small>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0);">
                                <div class="feeds-left bg-green"><i class="fa fa-thumbs-o-up"></i></div>
                                <div class="feeds-body">
                                    <h4 class="title text-success">2 بازخورد جدید <small class="float-right text-muted">9:10 صبح</small></h4>
                                    <small>این یک پایان هوشمند برای سایت شما خواهد بود</small>
                                </div>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown language-menu">
                    <a href="javascript:void(0);" class="dropdown-toggle icon-menu" data-toggle="dropdown">
                        <i class="fa fa-language"></i>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item pt-2 pb-2" href="#"><img src="<?php echo e(asset('admin/assets/images/flag/us.svg')); ?>" class="w20 mr-2 rounded-circle"> انگلیسی آمریکایی</a>
                        <a class="dropdown-item pt-2 pb-2" href="#"><img src="<?php echo e(asset('admin/assets/images/flag/gb.svg')); ?>" class="w20 mr-2 rounded-circle"> انگلیسی انگلیسی</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item pt-2 pb-2" href="#"><img src="<?php echo e(asset('admin/assets/images/flag/russia.svg')); ?>" class="w20 mr-2 rounded-circle"> روسی</a>
                        <a class="dropdown-item pt-2 pb-2" href="#"><img src="<?php echo e(asset('admin/assets/images/flag/arabia.svg')); ?>" class="w20 mr-2 rounded-circle"> عربی</a>
                        <a class="dropdown-item pt-2 pb-2" href="#"><img src="<?php echo e(asset('admin/assets/images/flag/france.svg')); ?>" class="w20 mr-2 rounded-circle"> فرانسوی</a>
                    </div>
                </li>
                <li><a href="javascript:void(0);" class="megamenu_toggle icon-menu" title="منوی مگا">مگا</a></li>

            </ul>
        </div>

        <div class="navbar-right">
            <div id="navbar-menu">
                <ul class="nav navbar-nav">
                    <li><a href="javascript:void(0);" class="search_toggle icon-menu" title="Search Result"><i class="icon-magnifier"></i></a></li>
                    <li><a href="javascript:void(0);" class="right_toggle icon-menu" title="Right Menu"><i class="icon-bubbles"></i><span class="notification-dot bg-pink">2</span></a></li>
                    <li><a href="page-login.html" class="icon-menu"><i class="icon-power"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="progress-container"><div class="progress-bar" id="myBar"></div></div>
</nav>
<?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/users/top_navbar.blade.php ENDPATH**/ ?>