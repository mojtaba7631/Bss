<?php $__env->startSection('title',"پنل ادمین"); ?>;
<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">پنل ادمین</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('admin_new_index')); ?>">خبر <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin_settings_index')); ?>">تنظیمات</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin_media_index')); ?>">مدیا</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin_category_index')); ?>">دسته بندی</a>
            </li>
        </ul>
    </div>
</nav>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/nav.blade.php ENDPATH**/ ?>