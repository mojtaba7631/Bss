<?php $__env->startSection('title','کاربران'); ?>
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row clearfix">
                    <div class="col-md-6 col-sm-12">
                        <h1>کاربران</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">نوپیا</a></li>
                                <li class="breadcrumb-item active" aria-current="page">کاربران</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-md-6 col-sm-12 text-right hidden-xs">
                        <a href="javascript:void(0);" class="btn btn-sm btn-primary" title="">ایجاد کمپین</a>
                        <a href="https://www.rtl-theme.com/author/paradigmshift" class="btn btn-sm btn-success" title="راست چین"><i class="icon-basket"></i> خرید قالب</a>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <ul class="nav nav-tabs">
                            <li class="nav-item"><a class="nav-link active show" data-toggle="tab" href="#Users">کاربران</a></li>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#addUser">افزودن کاربر</a></li>
                        </ul>
                        <div class="tab-content mt-0">
                            <div class="tab-pane show active" id="Users">
                                <div class="table-responsive">
                                    <table class="table table-hover table-custom spacing8">
                                        <thead>
                                        <tr>
                                            <th class="w60">نام</th>
                                            <th></th>
                                            <th></th>
                                            <th>تاریخ ایجاد شده</th>
                                            <th>نقش</th>
                                            <th class="w100">اقدام</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td class="width45">
                                                <div class="avtar-pic w35 bg-pink" data-toggle="tooltip" data-placement="top" title="نام آواتار"><span>MN</span></div>
                                            </td>
                                            <td>
                                                <h6 class="mb-0">آش خادملو</h6>
                                                <span>marshall-n@gmail.com</span>
                                            </td>
                                            <td><span class="badge badge-danger">مدیر کل</span></td>
                                            <td>25 اسفند 1397</td>
                                            <td>طراح وب</td>
                                            <td>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="../assets/images/xs/avatar5.jpg" data-toggle="tooltip" data-placement="top" title="نام آواتار" alt="Avatar" class="w35 h35 rounded">
                                            </td>
                                            <td>
                                                <h6 class="mb-0">آش خادملو</h6>
                                                <span>sussie-w@gmail.com</span>
                                            </td>
                                            <td><span class="badge badge-info">مدیر</span></td>
                                            <td>25 اسفند 1397</td>
                                            <td>طراح وب</td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-default" title="Edit"><i class="fa fa-edit"></i></button>
                                                <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="../assets/images/xs/avatar4.jpg" data-toggle="tooltip" data-placement="top" title="نام آواتار" alt="Avatar" class="w35 h35 rounded">
                                            </td>
                                            <td>
                                                <h6 class="mb-0">آش خادملو</h6>
                                                <span>debra@gmail.com</span>
                                            </td>
                                            <td><span class="badge badge-info">مدیر</span></td>
                                            <td>25 اسفند 1397</td>
                                            <td>طراح وب</td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-default" title="Edit"><i class="fa fa-edit"></i></button>
                                                <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <img src="../assets/images/xs/avatar7.jpg" data-toggle="tooltip" data-placement="top" title="نام آواتار" alt="Avatar" class="w35 h35 rounded">
                                            </td>
                                            <td>
                                                <h6 class="mb-0">آش خادملو</h6>
                                                <span>Erinonzales@gmail.com</span>
                                            </td>
                                            <td><span class="badge badge-default">کارمند</span></td>
                                            <td>25 اسفند 1397</td>
                                            <td>طراح وب</td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-default" title="Edit"><i class="fa fa-edit"></i></button>
                                                <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="avtar-pic w35 bg-blue" data-toggle="tooltip" data-placement="top" title="نام آواتار"><span>MN</span></div>
                                            </td>
                                            <td>
                                                <h6 class="mb-0">آش خادملو</h6>
                                                <span>alexander@gmail.com</span>
                                            </td>
                                            <td><span class="badge badge-success">طراح وب مدیر</span></td>
                                            <td>25 اسفند 1397</td>
                                            <td>طراح وب</td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-default" title="Edit"><i class="fa fa-edit"></i></button>
                                                <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane" id="addUser">
                                <div class="body mt-2">
                                    <div class="row clearfix">
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="نام اصلی *">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="نام خانوادگی">
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="شناسهایمیل *">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="رمز عبور">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="تایید رمز عبور">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="شماره تلفن">
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="شناسه کارمند *">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="نام کاربری *">
                                            </div>
                                        </div>
                                        <div class="col-lg-3 col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <select class="form-control show-tick">
                                                    <option>انتخاب نوع نقش</option>
                                                    <option>مدیر کل</option>
                                                    <option>مدیر</option>
                                                    <option>کارمند</option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <h6>ماژول اجازه</h6>
                                            <div class="table-responsive">
                                                <table class="table table-striped">
                                                    <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>خاندن</th>
                                                        <th>نوشتن</th>
                                                        <th>حذف</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <tr>
                                                        <td>مدیر کل</td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>مدیر</td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>کارمند</td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>طراح وب مدیر</td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox" checked>
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                        <td>
                                                            <label class="fancy-checkbox">
                                                                <input class="checkbox-tick" type="checkbox" name="checkbox">
                                                                <span></span>
                                                            </label>
                                                        </td>
                                                    </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <button type="button" class="btn btn-primary">افزودن</button>
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">بستن</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.panel.users_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/users.blade.php ENDPATH**/ ?>