<?php $__env->startSection('title','اخبار'); ?>
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row clearfix">
                    <div class="col-md-6 col-sm-12">
                        <h1>اخبار</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">نوپیا</a></li>
                                <li class="breadcrumb-item active" aria-current="page">اخبار</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-md-6 col-sm-12 text-right hidden-xs">
                        <a href="<?php echo e(url('admin/panel/new/add/')); ?>" class="btn btn-sm btn-primary" title="">افزودن خبر</a>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="tab-content mt-0">
                            <div class="tab-pane show active" id="Users">
                                <div class="table-responsive">
                                    <table class="table table-hover table-custom spacing8">
                                        <thead>
                                        <tr>
                                            <th class="w60"></th>
                                            <th>عنوان</th>
                                            <th>وضعیت</th>
                                            <th>دسته بندی</th>
                                            <th>تاریخ ایجاد شده</th>
                                            <th>برچسب</th>
                                            <th class="w100">اقدام</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="width45">
                                                    <img src="<?php echo e(url($new->image)); ?>" data-toggle="tooltip" data-placement="top" title="نام آواتار" alt="Avatar" class="w35 h35 rounded">
                                                </td>
                                                <td>
                                                    <h6 class="mb-0"><?php echo e($new->title); ?></h6>
                                                    <span><?php echo e(mb_substr($new->meta_description,0,30,mb_detect_encoding($new->meta_description)).'...'); ?></span>
                                                </td>
                                                <td><?php echo e($new->status == 0  ? "پیش نویس" : "منتشرشده"); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $new->categories()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge badge-danger"><?php echo e($category->title); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>25 اسفند 1397</td>
                                                <td>
                                                    <?php $__currentLoopData = $new->tags()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge badge-danger"><?php echo e($tag->title); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(url('admin/panel/new/edit/' . $new->id)); ?>" style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-edit"></i></a>
                                                    <a href="<?php echo e(url('admin/panel/new/delete/' . $new->id)); ?>" style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-trash-o text-danger"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.panel.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/new/index.blade.php ENDPATH**/ ?>