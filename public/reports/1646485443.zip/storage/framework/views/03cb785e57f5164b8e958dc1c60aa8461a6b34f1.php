<?php $__env->startSection('title',"اخبار"); ?>
<?php $__env->startSection('content'); ?>
    <div role="main" class="main">
        <section class="page-header page-header-modern bg-color-light-scale-1 page-header-md">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 align-self-center p-static order-2 text-center">
                        <h1 class="text-dark font-weight-bold text-8">اخبار</h1>
                        <span class="sub-title text-dark">آخرین اخبار نوپیا «نوآوری و پیشرفت ایران»</span>
                    </div>

                    <div class="col-md-12 align-self-center order-1">

                        <ul class="breadcrumb d-block text-center">
                            <li><a href="/" style="color: #fff">خانه</a></li>
                            <li class="active" style="color: #fff">اخبار</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <div class="container py-4">

            <div class="row">
                <div class="col">
                    <div class="blog-posts">

                        <div class="masonry-loader masonry-loader-showing">
                            <div class="masonry row" data-plugin-masonry data-plugin-options="{'itemSelector': '.masonry-item'}">

                                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="masonry-item no-default-style col-md-6 col-lg-4 col-xl-3">
                                        <article class="post post-medium border-0 pb-0 mb-5">
                                            <div class="post-image">
                                                <a href="<?php echo e(url('front/news/detail/' . $new->id)); ?>">
                                                    <img src="<?php echo e(url($new->image)); ?>"
                                                         class="img-fluid img-thumbnail img-thumbnail-no-borders rounded-0" alt="">
                                                </a>
                                            </div>

                                            <div class="post-content">

                                                <h2 class="font-weight-semibold text-5 line-height-7 mt-3 mb-2 pt-1">
                                                    <a href="<?php echo e(url('front/news/detail/' . $new->id)); ?>"><?php echo e($new['title']); ?></a></h2>
                                                <p class="text-justify"><?php echo e($new['meta_description']); ?></p>

                                                <div class="post-meta">
                                                    <span><i class="far fa-user"></i> توسط  <a href="#">تونی استارک</a> </span>
                                                    <span>
                                                        <i class="far fa-folder"></i>
                                                        <?php $__currentLoopData = $new->tags()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a href="#"><?php echo e($tag->title); ?></a>,
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </span>
                                                    <span><i class="far fa-comments"></i> <a href="#">12 دیدگاه</a></span>
                                                    <span class="d-block mt-2 pt-1"><a href="blog-post.html" class="btn btn-xs btn-light text-1 text-uppercase">بیشتر بخوانید</a></span>
                                                </div>

                                            </div>
                                        </article>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>












                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <ul class="pagination float-right">
                                    <li class="page-item"><a class="page-link" href="#"><i class="fas fa-angle-right"></i></a></li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item"><a class="page-link" href="#"><i class="fas fa-angle-left"></i></a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/front/news/index.blade.php ENDPATH**/ ?>