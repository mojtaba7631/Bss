<section class="section section-secondary border-0 py-0 m-0 appear-animation" data-appear-animation="fadeIn">
    <div class="container">
        <div class="row align-items-center justify-content-center justify-content-lg-between pb-5 pb-lg-0">
            <div class="col-lg-5 order-2 order-lg-1 pt-4 pt-lg-0 pb-5 pb-lg-0 mt-5 mt-lg-0 appear-animation"
                 data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">
                <h2 class="font-weight-bold text-color-light text-7 mb-2 pb-1">
                    <?php echo e($event->title); ?>

                </h2>
                <p class="font-weight-light text-color-light text-2 mb-4 opacity-7">
                    <?php echo e($event->meta_description); ?>

                </p>
                <a href="<?php echo e(url('front/event/detail/' . $event->id)); ?>" class="btn btn-dark-scale-2 btn-px-5 btn-py-2 text-2">مشاهده جزئیات</a>
            </div>
            <div class="col-9 offset-lg-1 col-lg-5 order-1 order-lg-2 scale-2">
                <img class="img-fluid box-shadow-3 my-2 border-radius"
                     src="<?php echo e($event->image); ?>" alt="">
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\nopia\resources\views/Home/quick_reg.blade.php ENDPATH**/ ?>