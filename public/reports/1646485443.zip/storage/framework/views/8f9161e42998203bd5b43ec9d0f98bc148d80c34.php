<?php $__env->startSection('title',"پنل اضافه کردن اخبار"); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <div class="card">
                <div class="card-header">اضافه کردن خبر</div>
                <div class="card-body">
                    <form method="post">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="title">عنوان</label>
                                    <input type="text" id="title" name="title" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="url">نامک</label>
                                    <input type="text" id="url" name="url" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="status">وضعیت</label>
                                    <select name="status" id="status" style="width: 100%">
                                        <option value="">--- انتخاب وضعیت ---</option>
                                        <option value="1">انتشار یافته</option>
                                        <option value="0">پیش نویس</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="categories">دسته بندی</label>
                                    <select  multiple name="categories[]" id="categories" style="width: 100%">
                                        <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="meta">متای خبر</label>
                                    <input type="text" id="meta" name="meta" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="tags">برچسب ها</label>
                                    <input type="text" id="tags" name="tags" class="form-control">

                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="description">متن خبر</label>
                                    <textarea name="description" id="description" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>




                        <hr>
                        <button type="submit" class="btn btn-success">ثبت خبر</button>
                        <a href="<?php echo e(url('admin/new')); ?>" class="btn btn-sm btn-gradient">بازگشت به اخبار</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/new/add.blade.php ENDPATH**/ ?>