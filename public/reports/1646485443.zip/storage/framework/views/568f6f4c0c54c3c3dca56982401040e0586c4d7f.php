<script src="<?php echo e(asset('site/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/jquery.appear/jquery.appear.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/jquery.cookie/jquery.cookie.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/popper/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/common/common.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/jquery.validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/jquery.gmap/jquery.gmap.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/jquery.lazyload/jquery.lazyload.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/isotope/jquery.isotope.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/vide/jquery.vide.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/vivus/vivus.min.js')); ?>"></script>

<!-- Theme Base, Components and Settings -->
<script src="<?php echo e(asset('site/js/theme.js')); ?>"></script>
<!-- Current Page Vendor and Views -->
<script src="<?php echo e(asset('site/vendor/rs-plugin/js/jquery.themepunch.tools.min.js')); ?>"></script>
<script src="<?php echo e(asset('site/vendor/rs-plugin/js/jquery.themepunch.revolution.min.js')); ?>"></script>

<!-- Theme Custom -->
<script src="<?php echo e(asset('site/js/custom.js')); ?>"></script>

<!-- Theme Initialization Files -->
<script src="<?php echo e(asset('site/js/theme.init.js')); ?>"></script>

<!-- Select2 -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>

    $(".js-example-tags").select2({
        tags: true
    });
</script>

<!-- Google Analytics: Change UA-XXXXX-X to be your site's ID. Go to http://www.google.com/analytics/ for more information.
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-12345678-1', 'auto');
    ga('send', 'pageview');
</script>
 -->
<?php /**PATH /Users/hamid/Codes/nopia_new/resources/views/css_js/scripts.blade.php ENDPATH**/ ?>