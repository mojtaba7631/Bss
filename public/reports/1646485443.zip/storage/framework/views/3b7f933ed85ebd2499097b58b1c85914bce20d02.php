<div id="counter" class="container">
    <div class="row r">
        <div class="col-3 text-center">
            <div class="my_circle">
                <span id="days"><?php echo e($days); ?></span>
                <span>روز</span>
            </div>
        </div>
        <div class="col-3">
            <div class="my_circle1">
                <span id="hours"><?php echo e($hours); ?></span>
                <span>ساعت</span>
            </div>
        </div>
        <div class="col-3">
            <div class="my_circle">
                <span id="minutes"><?php echo e($minutes); ?></span>
                <span>دقیقه</span>
            </div>
        </div>
        <div class="col-3">
            <div class="my_circle2">
                <span id="seconds"><?php echo e($seconds); ?></span>
                <span>ثانیه</span>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/hamid/Codes/nopia_new/resources/views/Home/counter.blade.php ENDPATH**/ ?>