<?php $__env->startSection('title','نوپیا'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .my_circle {
            width: 120px;
            height: 120px;
            border: 4px solid aqua;
            border-radius: 75px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: auto;
        }
        .my_circle1 {
            width: 120px;
            height: 120px;
            border: 4px solid yellow;
            border-radius: 75px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: auto;
        }
        .my_circle2 {
            width: 120px;
            height: 120px;
            border: 4px solid pink;
            border-radius: 75px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: auto;
        }
        .my_circle,.my_circle1,.my_circle2 span {
            margin: 5px;
            color: #000;
            font-size: 20px;
        }
        .r{
            width: 640px;
            margin: auto;
            /*background-color:#0a1339;*/
            padding: 10px;
            border-radius: 15px;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div role="main" class="main">

        

        <?php echo $__env->make('Home.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        

        <?php echo $__env->make('Home.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        

        <?php echo $__env->make('Home.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->make('Home.quick_reg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($speak->name); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        

        <?php echo $__env->make('Home.video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <?php echo $__env->make('Home.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>

        let s = document.getElementById('seconds');
        let m = document.getElementById('minutes');
        let h = document.getElementById('hours');
        let d = document.getElementById('days');
        let diff = parseInt("<?php echo e($diff); ?>");

        let seconds = diff % 60;
        let minutes = Math.floor(diff / 60) % 60;
        let hours = Math.floor((diff / 60) / 60) % 24;
        let days = Math.floor(((diff / 60) / 60) / 24);

        setInterval(function () {
            s.textContent = seconds;
            m.textContent = minutes;
            h.textContent = hours;
            d.textContent = days;
            diff --;
            seconds = diff % 60;
            minutes = Math.floor(diff / 60) % 60;
            hours = Math.floor((diff / 60) / 60) % 24;
            days = Math.floor(((diff / 60) / 60) / 24);
        }, 1000)
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.index_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/hamid/Codes/nopia_new/resources/views/Home/index.blade.php ENDPATH**/ ?>