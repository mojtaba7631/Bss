<div class="container">
    <div class="row">
        <div class="col-12 text-center mt-5">
            <h3>آخرین اخبار</h3>
        </div>
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-md-3">
            <div class="post-image">
                <a href="<?php echo e(url('front/news/detail/' . $new->id)); ?>">
                    <img src="<?php echo e(url($new->image)); ?>"
                         class="img-fluid img-thumbnail img-thumbnail-no-borders rounded-0" alt="">
                </a>
            </div>
            <h2 class="font-weight-semibold text-3 line-height-7 mt-3 mb-2 pt-1">
                <a href="<?php echo e(url('front/news/detail/' . $new->id)); ?>"><?php echo e($new['title']); ?></a>
            </h2>
            <p class="text-justify"><?php echo e(mb_substr($new['meta_description'],0,100,mb_detect_encoding($new['meta_description'])).'...'); ?></p>
        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /Users/hamid/Codes/nopia_new/resources/views/Home/news.blade.php ENDPATH**/ ?>