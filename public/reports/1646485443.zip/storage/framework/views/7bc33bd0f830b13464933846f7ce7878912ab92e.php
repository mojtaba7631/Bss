<?php $__env->startSection('title','رسانه'); ?>
<?php $__env->startSection('content'); ?>
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row clearfix">
                    <div class="col-md-6 col-sm-12">
                        <h1>رسانه</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">نوپیا</a></li>
                                <li class="breadcrumb-item active" aria-current="page">رسانه</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-md-6 col-sm-12 text-right hidden-xs">
                        <a href="<?php echo e(url('admin/panel/event/media/add/' . $event->id)); ?>" class="btn btn-sm btn-primary" title="">افزودن رسانه</a>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="tab-content mt-0">
                            <div class="tab-pane show active" id="Users">
                                <div class="table-responsive">
                                    <table class="table table-hover table-custom spacing8">
                                        <thead>
                                        <tr>
                                            <th class="w60"></th>
                                            <th>عنوان</th>
                                            <th>تاریخ ایجاد شده</th>
                                            <th class="w100">اقدام</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="width45">
                                                    <img src="<?php echo e(url($mass->image ?? "placeholder/placeholder.png")); ?>" data-toggle="tooltip" data-placement="top" title="نام آواتار" alt="Avatar" class="w35 h35 rounded">
                                                </td>
                                                <td>
                                                    <h6 class="mb-0"><?php echo e($mass->title); ?></h6>
                                                    <span>
                                                        <?php echo e(mb_substr(strip_tags($mass->description),0,30,mb_detect_encoding($mass->description)).'...'); ?>

                                                    </span>
                                                </td>

                                                <td>25 اسفند 1397</td>
                                                <td>
                                                    <a href="<?php echo e(url('admin/panel/event/media/edit/' . $event->id . '/' . $mass->id)); ?>" style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-edit"></i></a>
                                                    <a href="<?php echo e(url('admin/panel/event/media/view/' . $event->id . '/' . $mass->id)); ?>" style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-search"></i></a>
                                                    <a href="<?php echo e(url('admin/panel/event/media/delete/' . $event->id . '/' . $mass->id)); ?>" style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-trash-o text-danger"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.panel.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nopia\resources\views/admin/panel/event/media/index.blade.php ENDPATH**/ ?>