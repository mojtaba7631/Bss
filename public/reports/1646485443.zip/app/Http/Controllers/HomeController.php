<?php

namespace App\Http\Controllers;

use App\Models\Aboutus;
use App\Models\Event;
use App\Models\News;
use App\Models\Settings;
use Carbon\Carbon;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {

        $aboutus = Aboutus::first()->description;
        $aboutus_img = Aboutus::first()->image;
        //        $articles = Article::where('id','>',2)->orderBy('id','desc')->get() ;

        $event = Event::where('show_site', 1)->first();
        $speakers = $event->speakers()->get();

        $last_video = $event->media()->where('aparat_link','!=',null)->orderBy('id','desc')->first();



        $news = News::all();

//        dd($aboutus);

        $deadline = Carbon::createFromTimeString(Settings::first()->deadline);

        $days = Carbon::now()->diffInDays($deadline);
        $hours = Carbon::now()->diffInHours($deadline) % 24;
        $minutes = Carbon::now()->diffInMinutes($deadline) % 60;
        $seconds = Carbon::now()->diffInSeconds($deadline) % 60;

        $diff = Carbon::now()->diffInSeconds($deadline);

        return view('Home.index', [
            'news' => $news,
            'aboutus' => $aboutus,
            'aboutus_img' => $aboutus_img,
            'diff' => $diff,
            'days' => $days,
            'hours' => $hours,
            'minutes' => $minutes,
            'seconds' => $seconds,
            'event' => $event,
            'speakers' => $speakers,
            'last_video' => $last_video
        ]);


    }

    public function detail(Event $event)
    {
        return view('front.event.detail', ['event' => $event]);

    }
}
