<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Cache\RetrievesMultipleKeys;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use App\Models\Category;

class CategoryController extends Controller
{
    public function index(){
        $categories = Category::orderBy('id','asc')->get();
        return view('admin.panel.category.index',['categories' => $categories]);
    }
    public function add(){
        return view('admin.panel.category.add');
    }
    public function create(Request $request){
        $category = new Category();
        $category->slug = $request->slug;
        $category->title = $request->title;
        $category->description = $request->description;
        $category->save();
        return redirect()->route('admin_category_index');
    }
    public function edit(Category $category){
        return view('admin.panel.category.edit',['category'=>$category]);
    }
    public function update(Category $category, Request $request){
        $category->slug = $request->slug;
        $category->title = $request->title;
        $category->description = $request->description;
        $category->save();
        return redirect()->route('admin_category_index');
    }

    public  function delete(Category $category){
        $category->delete();
    return redirect()->route('admin_category_index');
}

}
