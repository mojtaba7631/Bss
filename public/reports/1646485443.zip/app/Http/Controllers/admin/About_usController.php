<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Aboutus;
use App\Models\News;
use App\Models\Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class About_usController extends Controller
{
    public function index(){
        $about_us = Aboutus::all();
        return view('admin.panel.about_us.index',compact('about_us'));
    }

        public function index_site(){
            $aboutus = Aboutus::first()->description;
            $introducing_us = Aboutus::first()->Introducing_us;
            $our_vision = Aboutus::first()->Our_vision;
            $our_mission = Aboutus::first()->Our_mission;
            $progress_bar_name1 = Aboutus::first()->progress_bar_name1;
            $progress_bar_name2 = Aboutus::first()->progress_bar_name2;
            $progress_bar_name3 = Aboutus::first()->progress_bar_name3;
            $progress_bar_name4 = Aboutus::first()->progress_bar_name4;
            $progress_bar_cent1 = Aboutus::first()->progress_bar_cent1;
            $progress_bar_cent2 = Aboutus::first()->progress_bar_cent2;
            $progress_bar_cent3 = Aboutus::first()->progress_bar_cent3;
            $progress_bar_cent4 = Aboutus::first()->progress_bar_cent4;
            $conductor_title = Aboutus::first()->Conductor_title;
            $f_image = Aboutus::first()->f_image;
            $s_image = Aboutus::first()->s_image;

            return view('Aboutus.about',[
                'aboutus'=> $aboutus,
                    'introducing_us'=>$introducing_us ,
                    'our_vision'=>$our_vision,
                    'our_mission'=>$our_mission,
                    'progress_bar_name1'=>$progress_bar_name1,
                    'progress_bar_name2'=>$progress_bar_name2,
                    'progress_bar_name3'=>$progress_bar_name3,
                    'progress_bar_name4'=>$progress_bar_name4,
                    'progress_bar_cent1'=>$progress_bar_cent1,
                    'progress_bar_cent2'=>$progress_bar_cent2,
                    'progress_bar_cent3'=>$progress_bar_cent3,
                    'progress_bar_cent4'=>$progress_bar_cent4,
                    'conductor_title'=>$conductor_title,
                    'f_image'=>$f_image,
                    's_image'=>$s_image,
                ]
            );
    }

    public function add(){
        return view('admin.panel.about_us.add');
    }

    public function create(Request $request){
//        dd($path);
        $this->validate($request,[
           'image' => 'image|mimes:png,jpg,gif|required'
        ]);


        $path = $request->file('image')->store('images');
        $path1 = $request->file('f_image')->store('images');
        $path2 = $request->file('s_image')->store('images');

        $about = new Aboutus();
        $about->progress_bar_name1 = $request->progress_bar_name1;
        $about->progress_bar_name2 = $request->progress_bar_name2;
        $about->progress_bar_name3 = $request->progress_bar_name3;
        $about->progress_bar_name4 = $request->progress_bar_name4;
        $about->progress_bar_cent1 = $request->progress_bar_cent1;
        $about->progress_bar_cent2 = $request->progress_bar_cent2;
        $about->progress_bar_cent3 = $request->progress_bar_cent3;
        $about->progress_bar_cent4 = $request->progress_bar_cent4;
//        $about->title = $request->title;
        $about->Our_mission = $request->Our_mission;
        $about->Our_vision = $request->Our_vision;
        $about->description = $request->description;
        $about->Introducing_us = $request->Introducing_us;

        $about->image = $path;
        $about->f_image = $path1;
        $about->s_image = $path2;
        $about->save();

        return redirect()->route('admin_about_index');
    }

    public function edit(Aboutus $about){

        return view('admin.panel.about_us.edit', ['about' => $about]);
    }

    public  function update(Aboutus $about , Request $request){
//        dd($request->all());
        $about->Our_mission = $request->Our_mission;
        $about->Our_vision = $request->Our_vision;
        $about->description = $request->description;
        $about->Introducing_us = $request->Introducing_us;

        $about->progress_bar_name1 = $request->progress_bar_name1;
        $about->progress_bar_name2 = $request->progress_bar_name2;
        $about->progress_bar_name3 = $request->progress_bar_name3;
        $about->progress_bar_name4 = $request->progress_bar_name4;
        $about->progress_bar_cent1 = $request->progress_bar_cent1;
        $about->progress_bar_cent2 = $request->progress_bar_cent2;
        $about->progress_bar_cent3 = $request->progress_bar_cent3;
        $about->progress_bar_cent4 = $request->progress_bar_cent4;

        if (isset($request->image)){
            if ($about->image != null){
                if(file_exists(getcwd().'/'.$about->image))
                {
                    unlink(getcwd().'/'.$about->image);
                }
            }
            $about->image = $request->file('image')->store('images');
        }
        if (isset($request->f_image)){
            if ($about->f_image != null){
                if(file_exists(getcwd().'/'.$about->f_image))
                {
                    unlink(getcwd().'/'.$about->f_image);
                }
            }
            $about->f_image= $request->file('f_image')->store('images');
        }
        if (isset($request->s_image)){
            if ($about->s_image != null){
                if(file_exists(getcwd().'/'.$about->s_image))
                {
                    unlink(getcwd().'/'.$about->s_image);
                }
            }
            $about->s_image = $request->file('s_image')->store('images');
        }

        $about->save();


        return redirect()->route('admin_about_index');

    }
    public  function delete(Aboutus $about){
        $about->delete();
        return redirect()->route('admin_about_index');
    }
}
