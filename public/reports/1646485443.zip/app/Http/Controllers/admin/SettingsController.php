<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Settings;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function index(){
        $settings = Settings::query()->get();
        return view('admin.settings.index',compact('settings'));
    }

    public function add(){
        return view('admin.settings.add');
    }

    public function create(Request $request){
//        dd($request->all());
        $settings = new Settings();
        $settings->tell1 = $request->tell1;
        $settings->tell2 = $request->tell2;
        $settings->email = $request->email;
        $settings->map = $request->map;
        $settings->address = $request->address;
        $settings->save();
        return redirect()->route('admin_settings_index');

    }
    public function edit(Settings $settings){
        return view('admin.settings.edit',['settings'=>$settings]);
    }

    public function update(Settings $settings , Request $request){
        $settings->tell1 = $request->tell1;
        $settings->tell2 = $request->tell2;
        $settings->map = $request->map;
        $settings->address = $request->address;
        $settings->email = $request->email;
        $settings->save();
        return redirect()->route('admin_settings_index');

    }
}
