<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Event;
use Illuminate\Http\Request;

class EventController extends Controller
{
    public function index(){
        $events = Event::all();
        return view('admin.panel.event.index',compact('events'));
    }

    public function add(){
        return view('admin.panel.event.add');
    }

    public function create(Request $request){
        $path = $request->file('file')->store('image');

        $event = new Event();
        $event->title = $request->title;
        $event->meta_description = $request->meta_description;
        $event->description = $request->description;
        $event->show_site = $request->show_site;
        $event->image = $path;
        $event->save();
        return redirect()->route('admin_event_index');
    }

    public function edit(Event $event){
        return view('admin.panel.event.edit', ['event' => $event]);
    }

    public function update(Event $event , Request $request){
        $event->title = $request->title;
        $event->meta_description = $request->meta_description;
        $event->description = $request->description;
        $event->show_site = $request->show_site;
//        $event->image = $path;
        $event->save();
        return redirect()->route('admin_event_index');

    }

    public function speaker(Event $event){
//         dd($event);
        return view('admin.panel.event.speaker.index',compact('event'));
    }

    public  function delete(Event $event){
        $event->delete();
        return redirect()->route('admin_event_index');
    }


}
