<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\Speaker;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SpeakerController extends Controller
{
    public function index(Event $event)
    {
        $data['speaker'] = $event->speakers()->get();
        $data['event'] = $event;
        return view('admin.panel.event.speaker.index', $data);

    }

    public function add(Event $event)
    {
        return view('admin.panel.event.speaker.add', compact('event'));
    }

    public function create(Event $event, Request $request)
    {
        $this->validate($request, [
            'image' => 'image|nullable'
        ]);
//dd($event);
        $speak = new Speaker();
        $speak->name = $request->name;
        $speak->family = $request->family;
        $speak->post = $request->post;
        $speak->evidence = $request->evidence;
        if (isset($request->image)){
            $speak->image =$request->file('image')->store('images');
        }
        $speak->event_id = $event->id;
        $speak->save();


        return redirect()->route('admin_speaker_index', ['event' => $event->id]);
    }

}
