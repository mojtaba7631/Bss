<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Image;
use App\Models\Media;
use App\Models\News;
use App\Models\Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class NewController extends Controller
{
    public function index() {
//        $articles = Article::all();
//        $articles = Article::where('id','>',2)->orderBy('id','desc')->get() ;
//        $articles = Article::orderBy('id','asc')->count() dd($articles) ;
//        $articles = Article::orderBy('id','asc')->sum('id') dd($articles) ;
//        $articles = Article::orderBy('id','asc')->max('id') dd($articles) ;
        $news = News::query()->latest()->get() ;

        return view('admin.panel.new.index',compact('news'));
    }
    public function add(){

        return view('admin.panel.new.add');
    }

    public function create(Request $request){
//         dd($request->all());
        $path = $request->file('file')->store('images');

        $new = new News();
        $new->slug = $request->slug;
        $new->title = $request->title;
        $new->status = $request->status;
        $new->meta_description = $request->meta_description;
        $new->description = $request->description;
        $new->image = $path;
        $new->save();

        $categories = $request->categories;



        foreach($categories as $category_id) {
            DB::table('category_news')->insert([
                'news_id' => $new->id,
                'category_id' => $category_id
            ]);
        }

        $tags = explode(',', $request->tags);
        // ['test1' , 'test2']
        foreach($tags as $title){
            $tag = Tag::where('title',$title)->first();
            if($tag){
                DB::table('news_tag')->insert([
                    'news_id' => $new->id,
                    'tag_id' => $tag->id
                ]);
            }
            else{
                $tag = new Tag();
                $tag->title = $title;
                $tag->slug = Str::slug($title);
                $tag->save();
                DB::table('news_tag')->insert([
                    'news_id' => $new->id,
                    'tag_id' => $tag->id
                ]);
            }
        }

        return redirect()->route('admin_new_index');
    }

    public function edit(News $new){
        $tags = $new->tags()->pluck('title')->toArray();
        $categories = $new->categories()->pluck('id')->toArray();

        $tag_string = implode(',', $tags);
        return view('admin.panel.new.edit', ['new' => $new , 'tag_string' => $tag_string,'categories'=>$categories]);
    }

    public function view (News $new){
//        dd($new);
        return view('admin.panel.new.view',compact('new'));
    }

    public  function update(News $new , Request $request){
//        dd($request->all());
        $new->title = $request->title;
        $new->slug = $request->slug;
        $new->status = $request->status;
        $new->meta_description = $request->meta_description;
        $new->description = $request->description;
        $new->save();

        $categories = $request->categories;

//        foreach($categories as $category_id) {
//            DB::table('category_news')->insert([
//                'news_id' => $new->id,
//                'category_id' => $category_id
//            ]);
//        }

        $new->categories()->sync($categories);

        $tags = explode(',', $request->tags);
        if (count($tags)>5){
            return back()->withInput();
        }
        $ids = [];
        foreach($tags as $title){
            $tag = Tag::where('title',$title)->first();
            if($tag){
                $ids[] = $tag->id;
            }
            else{
                $tag = new Tag();
                $tag->title = $title;
                $tag->slug = Str::slug($title);
                $tag->save();
                $ids[] = $tag->id;
            }
        }

        $new->tags()->sync($ids);

        return redirect()->route('admin_new_index');

    }

    public  function delete(News $new){
        $new->delete();
        return redirect()->route('admin_new_index');
    }

}
