<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\Media;
use App\Models\Image;
use App\Models\Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class MediaController extends Controller
{
    public function index(Event $event)
    {
        $data['media'] = $event->media()->get();
        $data['last_media'] = Media::orderBy('id', 'desc')->get();
        $data['event'] = $event;
        return view('admin.panel.event.media.index', $data);
    }

    public function view(Event $event, Media $media)
    {

        // dd($event->images()->first());
        return view('admin.panel.event.media.view', compact('media', 'event'));
    }

    public function add_image(Media $media, Request $request)
    {

//        dd('we are here');
        $this->validate($request, [
            'title' => 'required',
//           'slug' => 'required|unique:images',
            'file' => 'image',
        ]);

//        dd($request->file('file')->extension());
        $path = $request->file('file')->store('images');

        $image = new Image();
        $image->title = $request->title;
        $image->path = $path;
        $image->alt = $request->description;
        $image->media_id = $media->id;
        $image->status = 0;
        $image->save();
        return back();
    }


    public function remove_image(Image $image)
    {

        if (file_exists(getcwd() . '/' . $image->path)) {
            unlink(getcwd() . '/' . $image->path);
        }
        $image->delete();

        return back();
    }

    public function add(Event $event)
    {
        return view('admin.panel.event.media.add', compact('event'));
    }

    public function create(Event $event, Request $request)
    {
        $this->validate($request, [
            'image' => 'image|nullable'
        ]);
//dd($event);
        $media = new Media();
        $media->title = $request->title;
        $media->slug = $request->slug;
        $media->description = $request->description;
        $media->aparat_link = $request->aparat_link;
        if (isset($request->image)){
            $media->image =$request->file('image')->store('images');
        }
        $media->event_id = $event->id;
        $media->save();


        return redirect()->route('admin_media_index', ['event' => $event->id]);
    }

    public function edit(Event $event, Media $media)
    {
        return view('admin.panel.event.media.edit', ['event' => $event, 'media' => $media]);
    }

    public function update(Event $event, Media $media, Request $request)
    {
        $this->validate($request, [
            'image' => 'image|nullable'
        ]);
//dd($event);

        $media->title = $request->title;
        $media->description = $request->description;
        $media->slug = $request->slug;
        $media->aparat_link = $request->aparat_link;
        $media->event_id = $event->id;
        if (isset($request->image)){
            $media->image =$request->file('image')->store('images');
        }
        $media->save();

        return redirect()->route('admin_media_index', ['event' => $event, 'media' => $media]);
    }

    public function delete(Media $med)
    {
        $med->delete();
        return redirect()->route('admin_media_index');
    }

}
