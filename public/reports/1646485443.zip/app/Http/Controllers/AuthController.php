<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Kavenegar;


class AuthController extends Controller
{
    public function register(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'password' => 'min:6|confirmed',
            'id_code' => 'max:10|min:10|unique:users',
            'mobile' => 'numeric|unique:users'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'ورودی ها درست وارد نشده اند.',
                'errors' => $validator->errors()
            ]);
        }
//        $this->validate($request,[
//            'name' => 'required',
//            'password' => 'min:6|confirmed',
//            'id_code' => 'max:10|min:10|unique:users',
//            'mobile' => 'numeric|unique:users'
//        ]);

        if (User::where('mobile',$request->mobile)->count() > 0 ){
            return response()->json([
               'status' => false,
                'message' => 'موبایل تکراری است'
            ]);
        }
        $user = new User();
        $user->name = $request->name;
        $user->family = $request->family;
//        $user->password = Hash::make($request->password);
        $user->id_code  = $request->id_code;
        $user->net  = $request->net;
        $user->otp = rand(1000,9999);
        $user->mobile  = $request->mobile;
        $user->type  = $request->type;
        $user->ghorfe  = $request->ghorfe;
        $user->panel  = $request->panel;
        $user->save();

//        return redirect('/login')->with('success_msg',"ثبت نام شما با موفقیت انجام شد");

        $message = "Your otp is: " . $user->otp;
//        $api_key = "70366638486877716D716C3476326A776B767276502B6E537577397441306A706D485A73397437576A35673D";
        // $kavenegar = new Kavenegar\KavenegarApi($api_key);
        // $kavenegar->send("10008663", $user->mobile, $message);

        $status = sms($user->mobile, $message);

        if ($status) {
            return response()->json([
                'status' => true,
                'message' => 'پیامک ارسال شد',
                'id' => $user->id
            ]);
        } else {
            return response()->json([
                'status' => false,
                'message' => 'خطا در ارسال پیامک',
            ]);
        }



    }
    public function login(Request $request){
        if (Auth::attempt([
            'name' => $request->name,
            'family' => $request->family,
            'id_code' => $request->id_code,
            'otp' => $request->otp,
            'mobile' => $request->mobile
        ])){
            return redirect('panel')
                ->with('Success','ورود شما با موفقیت انجام شد');
        }else{
            return back()->withInput()
                ->with('danger','ورود شما با خطا مواجه شد');
        }
    }

    public function logout(){
        Auth::logout();
        return redirect('login')
            ->with('Success','شما با موفقیت خارج شدید');
    }

    public function verify(Request $request){
        $user = User::find($request->id);
        if ($user->otp == $request->otp){
            Auth::login($user);
            $message = 'به رویداد نوپیا خوش آمدید';
            sms($user->mobile,$message);
            return response()->json([
               'status'=> true,
                'message' => 'ثبت نام با موفقیت انجام شد'
            ]);
        } else{
                return response()->json([
                    'status'=> false,
                    'message' => 'خطا در ارسال کد پیامکی'
                ]);
            }
    }
}
