<?php


function sms ($receptor, $message) {
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.ghasedak.me/v2/sms/send/simple",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "message=$message&receptor=$receptor&linenumber=3000772120&senddate=1508144471&checkid=1",
        CURLOPT_HTTPHEADER => array(
            "apikey: 5d9feff37917a7a5036940ef137be13f108d18b234811ddc705e11d8dd8668bd",
            "cache-control: no-cache",
            "content-type: application/x-www-form-urlencoded",
        ),
    ));
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    if ($err) {
        return false;
    } else {
        return true;
    }
}
