<?php

use App\Http\Controllers\admin\NewController as AdminNewsController;
use App\Http\Controllers\admin\EventController as AdminEventController;
use App\Http\Controllers\admin\SettingsController as AdminSettingsController;
use App\Http\Controllers\admin\CategoryController as AdminCategoryController;
use App\Http\Controllers\admin\MediaController as AdminMediaController;
use App\Http\Controllers\admin\About_usController as AdminAboutController;
use App\Http\Controllers\admin\SpeakerController as AdminSpeakerController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [\App\Http\Controllers\HomeController::class,'index'])->name('site');

//Route::get('/login', function () {
//    return view('Login.page-login');
//})->name('login');

Route::get('/contact_us', function () {
    return view('Contactus.contact');
})->name('contact');

Route::get('about_us', [AdminAboutController::class,'index_site'])->name('about_site');


Route::get('/test', function () {
    return view('admin.panel.new.test');
})->name('test');

Route::get('/panel',function (){
    return view('admin.panel.panel');
})->name('panel');

Route::get('/panel/users',function (){
    return view('admin.panel.users.users');
})->name('users');

Route::get('front/news',[NewsController::class,'index'])->name('new');
Route::get('front/news/detail/{new}',[NewsController::class,'detail'])->name('detail_new');
Route::get('front/event/detail/{event}',[HomeController::class,'detail'])->name('detail_event');

// ************************************* Admin Route *************************************
// example.com/admin
Route::group(['prefix' => 'admin/panel'], function () {
    // example.com/admin/news
    // ************************************* News Route *************************************
    Route::group(['prefix' => 'new'], function () {
        Route::get('/', [AdminNewsController::class, 'index'])->name('admin_new_index');
        Route::get('add', [AdminNewsController::class, 'add']);
        Route::post('add', [AdminNewsController::class, 'create']);
        Route::get('edit/{new}', [AdminNewsController::class, 'edit']);
        Route::post('edit/{new}', [AdminNewsController::class, 'update']);
        Route::get('view/{new}',[AdminNewsController::class,'view'])->name('admin_new_view');
        Route::get('delete/{new}', [AdminNewsController::class, 'delete']);
    });
    // ************************************* News Route *************************************


    // ************************************* About Route *************************************
    Route::group(['prefix' => 'about_us'], function () {
        Route::get('/', [AdminAboutController::class, 'index'])->name('admin_about_index');
        Route::get('add', [AdminAboutController::class, 'add']);
        Route::post('add', [AdminAboutController::class, 'create']);
        Route::get('edit/{about}', [AdminAboutController::class, 'edit']);
        Route::post('edit/{about}', [AdminAboutController::class, 'update']);
        Route::get('delete/{about}', [AdminAboutController::class, 'delete']);
    });
    // ************************************* About Route *************************************


// ************************************* Category Route *************************************
    Route::group(['prefix' => 'category'],function (){
       Route::get('/',[AdminCategoryController::class,'index'])->name('admin_category_index');
       Route::get('add',[AdminCategoryController::class,'add']);
       Route::post('add',[AdminCategoryController::class,'create']);
       Route::get('edit/{category}',[AdminCategoryController::class,'edit']);
       Route::post('edit/{category}',[AdminCategoryController::class,'update']);
        Route::get('delete/{category}', [AdminCategoryController::class, 'delete']);

    });
// ************************************* Category Route *************************************

// ************************************* Media Route *************************************
//    Route::group(['prefix' => 'media'], function () {
//        Route::get('/',[AdminMediaController::class,'index'])->name('admin_media_index');
//        Route::get('add',[AdminMediaController::class,'add']);
//        Route::post('add',[AdminMediaController::class,'create']);
//        Route::get('edit/{media}',[AdminMediaController::class,'edit']);
//        Route::post('edit/{media}',[AdminMediaController::class,'update']);
//        Route::get('view/{media}',[AdminMediaController::class,'view'])->name('admin_media_view');
//        Route::post('add_image/{media}',[AdminMediaController::class,'add_image']);
//        Route::get('remove_image/{image}',[AdminMediaController::class,'remove_image']);
//        Route::get('delete/{media}',[AdminMediaController::class,'delete']);
//    });
    // ************************************* Media Route *************************************

    // ************************************* event Route *************************************
    Route::group(['prefix' => 'event'], function () {
        Route::get('/', [AdminEventController::class, 'index'])->name('admin_event_index');
        Route::get('add', [AdminEventController::class, 'add']);
        Route::post('add', [AdminEventController::class, 'create']);
        Route::get('edit/{event}', [AdminEventController::class, 'edit']);
        Route::post('edit/{event}', [AdminEventController::class, 'update']);
        Route::get('/speaker/{event}',[AdminEventController::class,'speaker'])->name('admin_event_speaker');
        Route::get('delete/{event}', [AdminEventController::class, 'delete']);


        Route::group(['prefix' => 'media'], function () {
            Route::get('/{event}',[AdminMediaController::class,'index'])->name('admin_event_media');
            Route::get('add/{event}',[AdminMediaController::class,'add']);
            Route::post('add/{event}',[AdminMediaController::class,'create']);
            Route::get('edit/{event}/{media}',[AdminMediaController::class,'edit']);
            Route::post('edit/{event}/{media}',[AdminMediaController::class,'update']);
            Route::get('view/{event}/{media}',[AdminMediaController::class,'view'])->name('admin_media_view');
            Route::get('{event}',[AdminMediaController::class,'index'])->name('admin_media_index');
            Route::post('add_image/{event}/{media}',[AdminMediaController::class,'add_image']);
            Route::get('remove_image/{image}',[AdminMediaController::class,'remove_image']);
            Route::get('delete/{event}/{media}',[AdminMediaController::class,'delete']);
        });

        Route::group(['prefix' => 'speaker'],function(){
            Route::get('/{event}',[AdminSpeakerController::class,'index'])->name('admin_speaker_index');
            Route::get('add/{event}',[AdminSpeakerController::class,'add']);
            Route::post('add/{event}',[AdminSpeakerController::class,'create']);
        });

    });
    // ************************************* event Route *************************************

});
// ************************************* Settings Route *************************************
Route::group(['prefix' => 'admin/settings'], function () {
    Route::get('/',[AdminSettingsController::class,'index'])->name('admin_settings_index');
    Route::get('add',[AdminSettingsController::class,'add']);
    Route::post('add',[AdminSettingsController::class,'create']);
    Route::get('edit/{settings}',[AdminSettingsController::class,'edit']);
    Route::post('edit/{settings}',[AdminSettingsController::class,'update']);
});
// ************************************* Settings Route *************************************

Route::get('/portfolio', function () {
    return view('Portfolio.portfolio');
})->name('portfolio');

Route::get('/portfolio_single', function () {
    return view('Portfolio.portfolio_single');
})->name('portfolio_single');

Route::view('register','auth.register');
Route::view('login','auth.login')->name('login');;
Route::post('register',[AuthController::class,'register'])->name('register');
Route::post('verify',[AuthController::class,'verify']);

//Route::get('/article',[ArticleController::class,'index'])->name('article');
Route::get('send_sms', function () {
    sms("09199656693", 'test message');
});

Route::get('logout', function() {
    Auth::logout();
    return redirect('login');
});

