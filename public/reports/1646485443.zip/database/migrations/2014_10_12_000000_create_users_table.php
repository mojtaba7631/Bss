<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    //php artisan make:migration languages

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
//            $table->id();
//            $table->string('email')->unique();
//            $table->timestamp('email_verified_at')->nullable();
//            $table->string('password');
//            $table->boolean('role')->default(0);
//            $table->timestamp('birthday')->nullable();
//            $table->string('bio')->nullable();
//            $table->timestamps();
            $table->id();
            $table->string('name');
            $table->string('family');
//            $table->string('password');
            $table->string('mobile')->unique();
            $table->string('id_code')->unique();
            $table->string('net')->nullable();
            $table->integer('otp')->nullable();
            $table->boolean('type')->default(0);
            $table->boolean('ghorfe')->default(0);
            $table->boolean('panel')->default(0);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
