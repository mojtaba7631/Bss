<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Aboutus extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Aboutus', function (Blueprint $table) {
            $table->id();
            $table->text('description')->nullable();
            $table->text('Introducing_us')->nullable();
            $table->text('Our_vision')->nullable();
            $table->text('Our_mission')->nullable();
            $table->string('f_image')->nullable();
            $table->string('progress_bar_name1')->nullable();
            $table->string('progress_bar_name2')->nullable();
            $table->string('progress_bar_name3')->nullable();
            $table->string('progress_bar_name4')->nullable();
            $table->string('progress_bar_cent1')->nullable();
            $table->string('progress_bar_cent2')->nullable();
            $table->string('progress_bar_cent3')->nullable();
            $table->string('progress_bar_cent4')->nullable();
            $table->string('s_image')->nullable()->nullable();
            $table->timestamps();
            $table->string('image')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Aboutus');
    }
}
