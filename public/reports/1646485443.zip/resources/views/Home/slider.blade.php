<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img class="d-block w-100" src="{{asset('images/slider1.jpg')}}" alt="First slide">
            <div class="carousel-caption d-none d-md-block" style="top: 100px">
                <div class="row" style="width: 100%;margin: 0">
                    <div class="col-md-3"></div>
                    <div class="col-md-6 text-center">
                        <img src="{{asset('site/img/nopia_logo1.png')}}" alt=""
                             style="width: 160px;height:160px">
                    </div>
                    <div class="col-md-3"></div>
                    <div class="col-md-3"></div>
                    <div class="col-md-6" style="text-align: center">
                        <a href="{{route('about_site')}}" class="btn btn-dark-scale-2 btn-px-5 btn-py-2 text-2 mt-5">آشنایی
                            بیشتر</a>
                        <a href="{{route('register')}}" class="btn btn-success btn-px-5 btn-py-2 text-2 mt-5">ثبت
                            نام در نوپیا</a>
                    </div>
                    <div class="col-md-3"></div>
                </div>
            </div>
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="{{asset('images/slider2.jpg')}}" alt="Second slide">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100" src="{{asset('site/img/slides/slide-bg-7.jpg')}}" alt="Third slide">
{{--            <div id="22828860899"><script type="text/JavaScript" src="https://www.aparat.com/embed/dXJlT?data[rnddiv]=22828860899&data[responsive]=yes"></script></div>--}}
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
