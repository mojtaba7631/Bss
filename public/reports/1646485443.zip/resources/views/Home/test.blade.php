
{{--        <div class="container py-4">--}}
{{--            <div class="row pt-4 mt-5">--}}
{{--                <div class="col">--}}
{{--                    <div class="row pt-2 clearfix">--}}
{{--                        <div class="col-lg-6">--}}
{{--                            <div class="feature-box feature-box-style-2 reverse appear-animation"--}}
{{--                                 data-appear-animation="fadeInRightShorter">--}}
{{--                                <div class="feature-box-icon">--}}
{{--                                    <i class="icon-user-following icons text-color-primary"></i>--}}
{{--                                </div>--}}
{{--                                <div class="feature-box-info">--}}
{{--                                    <h4 class="mb-2">پشتیبانی مشتری</h4>--}}
{{--                                    <p class="mb-4 text-right">--}}
{{--                                        در سایت Iran Develop هر پروژه ای که توسط ما انجام شود به صورت کاملا تخصصی و--}}
{{--                                        دلسوزانه دارای پشتیبانی می باشد و هیچ گاه مشتری ناراضی نخواهد بود--}}
{{--                                    </p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                        <div class="col-lg-6">--}}
{{--                            <div class="feature-box feature-box-style-2 appear-animation"--}}
{{--                                 data-appear-animation="fadeInLeftShorter">--}}
{{--                                <div class="feature-box-icon">--}}
{{--                                    <i class="icon-globe icons text-color-primary"></i>--}}
{{--                                </div>--}}
{{--                                <div class="feature-box-info">--}}
{{--                                    <h4 class="mb-2">طراحی سایت</h4>--}}
{{--                                    <p class="mb-4">--}}
{{--                                        گروه فنی مهندسی Iran Develop هرگونه سایتی که مد نظر مشتری عزیز باشد با هر امکانی--}}
{{--                                        توسط طراحان متخصص طراحی و تقدیم می نماید--}}
{{--                                    </p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                    <div class="row">--}}
{{--                        <div class="col-lg-6">--}}
{{--                            <div class="feature-box feature-box-style-2 reverse appear-animation"--}}
{{--                                 data-appear-animation="fadeInRightShorter" data-appear-animation-delay="200">--}}
{{--                                <div class="feature-box-icon">--}}
{{--                                    <i class="icon-calculator icons text-color-primary"></i>--}}
{{--                                </div>--}}
{{--                                <div class="feature-box-info">--}}
{{--                                    <h4 class="mb-2">اتوماسیون</h4>--}}
{{--                                    <p class="mb-4">توانایی طراحی و اجرای هر گونه اتوماسیون به سلیقه شخصی مشتری</p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                        <div class="col-lg-6">--}}
{{--                            <div class="feature-box feature-box-style-2 appear-animation"--}}
{{--                                 data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="200">--}}
{{--                                <div class="feature-box-icon">--}}
{{--                                    <i class="icon-social-instagram icons text-color-primary"></i>--}}
{{--                                </div>--}}
{{--                                <div class="feature-box-info">--}}
{{--                                    <h4 class="mb-2">فضای مجازی</h4>--}}
{{--                                    <p class="mb-4">--}}
{{--                                        مدیریت پیج های فضای مجازی شما توسط ادمین حرفه ای و گرافیست متخصص--}}
{{--                                    </p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                    <div class="row">--}}
{{--                        <div class="col-lg-6">--}}
{{--                            <div class="feature-box feature-box-style-2 reverse appear-animation"--}}
{{--                                 data-appear-animation="fadeInRightShorter" data-appear-animation-delay="400">--}}
{{--                                <div class="feature-box-icon">--}}
{{--                                    <i class="icon-diamond icons text-color-primary"></i>--}}
{{--                                </div>--}}
{{--                                <div class="feature-box-info">--}}
{{--                                    <h4 class="mb-2">قیمت</h4>--}}
{{--                                    <p class="mb-4">--}}
{{--                                        شما در Iran Develop بهترین کار و با کیفیت ترین نتیجه را با بهترین و مناسب ترین--}}
{{--                                        قیمت در اختیار خواهید داشت--}}
{{--                                    </p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                        <div class="col-lg-6">--}}
{{--                            <div class="feature-box feature-box-style-2 appear-animation"--}}
{{--                                 data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="400">--}}
{{--                                <div class="feature-box-icon">--}}
{{--                                    <i class="icon-rocket icons text-color-primary"></i>--}}
{{--                                </div>--}}
{{--                                <div class="feature-box-info">--}}
{{--                                    <h4 class="mb-2">کیفیت</h4>--}}
{{--                                    <p class="mb-4">--}}
{{--                                        ما در Iran Develop در درجه اول به کیفیت می اندیشیم ، رضایت مشتری برای ما به--}}
{{--                                        منزله ی سود بیشتر است--}}
{{--                                    </p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--            <div class="row pb-5 mb-5 mt-3">--}}
{{--                <div class="col text-center">--}}
{{--                    <a href="#" class="btn btn-primary btn-px-5 py-3 font-weight-semibold text-2 appear-animation"--}}
{{--                       data-appear-animation="fadeInUpShorter" data-appear-animation-delay="300">آشنایی بیشتر</a>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}



{{--<section class="section section-height-4 bg-color-grey-scale-1 border-0 m-0 pb-5">--}}
{{--    <div class="container">--}}
{{--        <div class="row justify-content-center my-4">--}}
{{--            <div class="col appear-animation" data-appear-animation="fadeInUpShorter">--}}
{{--                <div class="owl-carousel owl-theme nav-bottom rounded-nav"--}}
{{--                     data-plugin-options="{'items': 1, 'loop': true, 'autoHeight': true}">--}}
{{--                    <div>--}}
{{--                        <div class="col">--}}
{{--                            <div--}}
{{--                                class="testimonial testimonial-style-2 testimonial-with-quotes testimonial-quotes-dark mb-0">--}}
{{--                                <div class="testimonial-author">--}}
{{--                                    <img src="{{asset('site/img/clients/client-1.jpg')}}"--}}
{{--                                         class="img-fluid rounded-circle" alt="">--}}
{{--                                </div>--}}
{{--                                <blockquote>--}}
{{--                                    <p class="text-color-dark text-5 line-height-9">لورم ایپسوم متن ساختگی با--}}
{{--                                        تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.--}}
{{--                                        چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و--}}
{{--                                        برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود--}}
{{--                                        ابزارهای</p>--}}
{{--                                </blockquote>--}}
{{--                                <div class="testimonial-author">--}}
{{--                                    <p class="opacity-10"><strong class="font-weight-extra-bold text-2">- بیل--}}
{{--                                            گیتس. مایکروسافت</strong></p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                    <div>--}}
{{--                        <div class="col">--}}
{{--                            <div--}}
{{--                                class="testimonial testimonial-style-2 testimonial-with-quotes testimonial-quotes-dark mb-0">--}}
{{--                                <div class="testimonial-author">--}}
{{--                                    <img src="{{asset('site/img/clients/client-1.jpg')}}"--}}
{{--                                         class="img-fluid rounded-circle" alt="">--}}
{{--                                </div>--}}
{{--                                <blockquote>--}}
{{--                                    <p class="text-color-dark text-5 line-height-9">لورم ایپسوم متن ساختگی با--}}
{{--                                        تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.--}}
{{--                                        چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و--}}
{{--                                        برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود--}}
{{--                                        ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و--}}
{{--                                        آینده شناخت فراوان جامعه و متخصصان را می طلبد</p>--}}
{{--                                </blockquote>--}}
{{--                                <div class="testimonial-author">--}}
{{--                                    <p class="opacity-10"><strong class="font-weight-extra-bold text-2">- بیل--}}
{{--                                            گیتس. مایکروسافت</strong></p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                    <div>--}}
{{--                        <div class="col">--}}
{{--                            <div--}}
{{--                                class="testimonial testimonial-style-2 testimonial-with-quotes testimonial-quotes-dark mb-0">--}}
{{--                                <div class="testimonial-author">--}}
{{--                                    <img src="{{asset('site/img/clients/client-1.jpg')}}"--}}
{{--                                         class="img-fluid rounded-circle" alt="">--}}
{{--                                </div>--}}
{{--                                <blockquote>--}}
{{--                                    <p class="text-color-dark text-5 line-height-9">لورم ایپسوم متن ساختگی با--}}
{{--                                        تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.--}}
{{--                                        چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و--}}
{{--                                        برای شرایط فعلی تکنولوژی مورد نیاز</p>--}}
{{--                                </blockquote>--}}
{{--                                <div class="testimonial-author">--}}
{{--                                    <p class="opacity-10"><strong class="font-weight-extra-bold text-2">- بیل--}}
{{--                                            گیتس. مایکروسافت</strong></p>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--</section>--}}




{{--<div class="container">--}}
{{--    <div class="row py-5 my-5">--}}
{{--        <div class="col">--}}

{{--            <div class="owl-carousel owl-theme mb-0"--}}
{{--                 data-plugin-options="{'responsive': {'0': {'items': 1}, '479': {'items': 3}, '768': {'items': 5}, '992': {'items': 7}, '1200': {'items': 7}}, 'autoplay': true, 'autoplayTimeout': 3000, 'dots': false}">--}}
{{--                <div>--}}
{{--                    <a href="https://nwbbco.de/" target="_blank">--}}
{{--                        <img class="img-fluid opacity-2" src="{{asset('site/img/logos/nwbbco_logo.png')}}"--}}
{{--                             alt="">--}}
{{--                    </a>--}}
{{--                </div>--}}
{{--                <div>--}}
{{--                    <a href="https://sewingmap.com/" target="_blank">--}}
{{--                        <img class="img-fluid opacity-2" src="{{asset('site/img/logos/sewing_logo.png')}}"--}}
{{--                             alt="">--}}
{{--                    </a>--}}
{{--                </div>--}}
{{--                <div>--}}
{{--                    <a href="http://rdfgroup.ir/" target="_blank">--}}
{{--                        <img class="img-fluid opacity-2" src="{{asset('site/img/logos/rdfGroup_logo.png')}}"--}}
{{--                             alt="">--}}
{{--                    </a>--}}
{{--                </div>--}}
{{--                <div>--}}
{{--                    <a href="https://tehranhifu.com/" target="_blank">--}}
{{--                        <img class="img-fluid opacity-2" src="{{asset('site/img/logos/tehranhifu_logo.png')}}"--}}
{{--                             alt="">--}}
{{--                    </a>--}}
{{--                </div>--}}
{{--            </div>--}}

{{--        </div>--}}
{{--    </div>--}}
{{--</div>--}}
