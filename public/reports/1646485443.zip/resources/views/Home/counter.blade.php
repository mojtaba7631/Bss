<div id="counter" class="container">
    <div class="row r">
        <div class="col-3 text-center">
            <div class="my_circle">
                <span id="days">{{ $days }}</span>
                <span>روز</span>
            </div>
        </div>
        <div class="col-3">
            <div class="my_circle1">
                <span id="hours">{{ $hours }}</span>
                <span>ساعت</span>
            </div>
        </div>
        <div class="col-3">
            <div class="my_circle">
                <span id="minutes">{{ $minutes }}</span>
                <span>دقیقه</span>
            </div>
        </div>
        <div class="col-3">
            <div class="my_circle2">
                <span id="seconds">{{ $seconds }}</span>
                <span>ثانیه</span>
            </div>
        </div>
    </div>
</div>
