<div class="container mt-5 mb-5">
    <div class="row">
        <div class="col-md-6 text-justify">
            <h3>درباره رویداد نوپیا</h3>
            <h5> بزرگتری رویداد نوآوری اجتماعی کشور </h5>
{{--            {{ mb_substr(strip_tags($aboutus),0,580,mb_detect_encoding($aboutus)) }}--}}
            {!! $aboutus !!}
            <a href="{{ route('about_site') }}"> مشاهده بیشتر </a>
        </div>
        <div class="col-md-6 text-center">
            <img style="width: 100%;height: 100%;margin: auto" src="{{ $aboutus_img }}" alt="">
        </div>
    </div>
</div>
