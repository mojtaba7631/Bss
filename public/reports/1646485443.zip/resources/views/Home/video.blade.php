@if(isset($last_video))
<div class="container-fluid mt-5 mb-5" style="background-color: #008080 ">
    <div class="row">
        <div class="col-12 col-md-8 p-5">
            @if(isset($last_video))
                {!! $last_video->aparat_link !!}
            @endif
        </div>
        <div class="col-12 col-md-4">
            <h3 class="m-auto text-center pt-3" style="color: #fff">{{$last_video->title}}</h3>
        </div>
    </div>
</div>
@endif