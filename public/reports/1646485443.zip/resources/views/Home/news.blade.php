<div class="container">
    <div class="row">
        <div class="col-12 text-center mt-5">
            <h3>آخرین اخبار</h3>
        </div>
        @foreach($news as $new)
        <div class="col-12 col-md-3">
            <div class="post-image">
                <a href="{{url('front/news/detail/' . $new->id)}}">
                    <img src="{{url($new->image)}}"
                         class="img-fluid img-thumbnail img-thumbnail-no-borders rounded-0" alt="">
                </a>
            </div>
            <h2 class="font-weight-semibold text-3 line-height-7 mt-3 mb-2 pt-1">
                <a href="{{url('front/news/detail/' . $new->id)}}">{{$new['title']}}</a>
            </h2>
            <p class="text-justify">{{mb_substr($new['meta_description'],0,100,mb_detect_encoding($new['meta_description'])).'...'}}</p>
        </div>
            @endforeach
    </div>
</div>
