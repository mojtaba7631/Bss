@extends('Layout.index_main')
@section('title','نوپیا')
@section('style')
    <style>
        .my_circle {
            width: 120px;
            height: 120px;
            border: 4px solid aqua;
            border-radius: 75px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: auto;
        }
        .my_circle1 {
            width: 120px;
            height: 120px;
            border: 4px solid yellow;
            border-radius: 75px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: auto;
        }
        .my_circle2 {
            width: 120px;
            height: 120px;
            border: 4px solid pink;
            border-radius: 75px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: auto;
        }
        .my_circle,.my_circle1,.my_circle2 span {
            margin: 5px;
            color: #000;
            font-size: 20px;
        }
        .r{
            width: 640px;
            margin: auto;
            /*background-color:#0a1339;*/
            padding: 10px;
            border-radius: 15px;
        }

    </style>
@endsection
@section('content')
    <div role="main" class="main">

        {{--        ********* slider--}}

        @include('Home.slider')

        {{--        ********* counter--}}

        @include('Home.counter')

        {{--        ********* about--}}

        @include('Home.about')

        {{--        ********* quick register--}}
        @include('Home.quick_reg')


        @foreach($speakers as $speak)
            {{$speak->name}}
            @endforeach

        {{--        ********* video--}}

        @include('Home.video')
        {{--        ********* news--}}

        @include('Home.news')

    </div>
@endsection
@section('js')
    <script>

        let s = document.getElementById('seconds');
        let m = document.getElementById('minutes');
        let h = document.getElementById('hours');
        let d = document.getElementById('days');
        let diff = parseInt("{{ $diff }}");

        let seconds = diff % 60;
        let minutes = Math.floor(diff / 60) % 60;
        let hours = Math.floor((diff / 60) / 60) % 24;
        let days = Math.floor(((diff / 60) / 60) / 24);

        setInterval(function () {
            s.textContent = seconds;
            m.textContent = minutes;
            h.textContent = hours;
            d.textContent = days;
            diff --;
            seconds = diff % 60;
            minutes = Math.floor(diff / 60) % 60;
            hours = Math.floor((diff / 60) / 60) % 24;
            days = Math.floor(((diff / 60) / 60) / 24);
        }, 1000)
    </script>
@endsection
