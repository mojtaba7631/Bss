<footer id="footer" class="mt-0">
    <div class="container my-4">
        <div class="row py-5">
            <div class="col-md-5 col-lg-3 mb-5 mb-lg-0">
                <h5 class="text-6 font-weight-semibold text-color-light mb-4">جزئیات تماس</h5>
                <p class="text-4 mb-1" style="color: #fff">
                    <i class="fa fa-check-circle" style="color:#fff"></i>
                    تبریز، فلکه دانشگاه
                </p>
                <p class="text-4 mb-4 pb-1" style="color:#fff;">برج بلور، طبقه 345</p>

                <p class="text-5 mb-0 pt-2" style="color: #fff">تماس:
                    <span class="ltr-text">123 456 7890</span>
                </p>
                <p class="text-5 mb-0" style="color: #fff">                    ایمیل:
                    <a href="mailto:info@porto.com" style="color: #fff">info@porto.com</a>
                </p>
            </div>
            <div class="col-md-7 col-lg-5 mb-5 mb-lg-0">
                <h5 class="text-6 font-weight-semibold text-color-light mb-4">صفحات</h5>
                <div class="row">
                    <div class="col-6" >
                        <p class="mb-1">
                            <i class="fa fa-check-circle" style="color:#fff"></i>
                            <a href="elements-call-to-action.html"  style="color: #fff" class="text-4 link-hover-style-1">نوار متنی</a></p>
                        <p class="mb-1">
                            <i class="fa fa-check-circle" style="color:#fff"></i>
                            <a href="elements-pricing-tables.html"  style="color: #fff" class="text-4 link-hover-style-1">جداول قیمت ها</a></p>
                        <p class="mb-1">
                            <i class="fa fa-check-circle" style="color:#fff"></i>
                            <a href="elements-word-rotator.html"  style="color: #fff" class="text-4 link-hover-style-1">گردش کلمات</a></p>
                        <p class="mb-1">
                            <i class="fa fa-check-circle" style="color:#fff"></i>
                            <a href="elements-tooltips-popovers.html"  style="color: #fff" class="text-4 link-hover-style-1">تولتیپ و پاپ اور</a></p>
                        <p class="mb-1">
                            <i class="fa fa-check-circle" style="color:#fff"></i>
                            <a href="elements-sticky-elements.html"  style="color: #fff" class="text-4 link-hover-style-1">عناصر چسبان</a></p>
                    </div>
                    <div class="col-6">
                        <p class="mb-1">
                            <i class="fa fa-check-circle" style="color:#fff"></i>
                            <a href="elements-progressbars.html" style="color: #fff" class="text-4 link-hover-style-1">نوارهای پیشرفت</a></p>
                        <p class="mb-1">
                            <i class="fa fa-check-circle" style="color:#fff"></i>
                            <a href="elements-sections-parallax.html" style="color: #fff" class="text-4 link-hover-style-1">بخش ها و پارالاکس</a></p>
                        <p class="mb-1">
                            <i class="fa fa-check-circle" style="color:#fff"></i>
                            <a href="elements-lists.html" style="color: #fff" class="text-4 link-hover-style-1">لیست ها</a></p>
                        <p class="mb-1">
                            <i class="fa fa-check-circle" style="color:#fff"></i>
                            <a href="elements-image-frames.html" style="color: #fff" class="text-4 link-hover-style-1">کادرهای تصویر</a></p>
                        <p class="mb-1">
                            <i class="fa fa-check-circle" style="color:#fff"></i>
                            <a href="elements-testimonials.html" style="color: #fff" class="text-4 link-hover-style-1">دیدگاه مشتریان</a></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4" style="color: #fff">
                <h5 class="text-6 font-weight-semibold text-color-light mb-4">خبرنامه</h5>
                <p class="text-4 mb-1" style="color: #fff">جدیدترین اخبار و پیشنهادات ما را دریافت کنید.</p>
                <p class="text-4" style="color: #fff">هم اکنون مشترک خبرنامه شوید.</p>
                <div class="alert alert-success d-none" id="newsletterSuccess">
                    <strong style="color: #daa520">موفقیت!</strong> شما به لیست ایمیل ما افزوده شدید.
                </div>
                <div class="alert alert-danger d-none" id="newsletterError"></div>
                <form id="newsletterForm" action="php/newsletter-subscribe.php" method="POST" class="mw-100">
                    <div class="input-group input-group-rounded">
                        <input class="form-control form-control-sm bg-light px-4 text-3 text-left" placeholder="... آدرس ایمیل" dir="ltr" name="newsletterEmail" id="newsletterEmail" type="text">
                        <span class="input-group-append">
										<button class="btn btn-primary text-color-light text-2 py-3 px-4" type="submit"><strong>اشتراک!</strong></button>
									</span>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="footer-copyright footer-copyright-style-2">
        <div class="container py-2">
            <div class="row py-4">
                <div class="col d-flex align-items-center justify-content-center">
                    <p>ارائه شده در وب‌سایت راست‌چین</p>
                </div>
            </div>
        </div>
    </div>
</footer>
