<!DOCTYPE html>
<html dir="rtl">
<head>
        <!-- Basic -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

         <title>@yield('title')</title>
        <meta name="keywords" content="HTML5 Template">
        <meta name="description" content="Porto - Responsive HTML5 Template">
        <meta name="author" content="okler.net">

        <!-- Favicon -->
        <link rel="shortcut icon" href="{{asset('site/img/favicon.ico')}}" type="image/x-icon">
        <link rel="apple-touch-icon" href="{{asset('site/img/apple-touch-icon.png')}}">

        <!-- Mobile Metas -->
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, shrink-to-fit=no">

        @include('css_js.styles')
</head>
<body>
    @include('nav_other')
    @yield('content')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    @yield('js')
    @include('footer')
    @include('css_js.scripts')
</body>
</html>
