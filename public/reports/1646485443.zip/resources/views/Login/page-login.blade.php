@extends('Layout.index')
@section('title',"ورود / ثبت نام");
@section('content')
    <div role="main" class="main">

        <section class="page-header page-header-classic">
            <div class="container">
                <div class="row">
                <div class="col-md-4 order-1 order-md-2 align-self-center">
                    <h1 class="mb-n2 mb-md-0">ثبت نام</h1>

                </div>
                <div class="col-md-8 order-2 order-md-1 align-self-center p-static">
                    <ul class="breadcrumb d-block text-md-left breadcrumb-light mb-1 mb-md-0">
                        <li><a href="/">خانه</a></li>
                        <li class="active">ورود / ثبت نام</li>
                    </ul>
                </div>
                </div>
            </div>
        </section>

        <div class="container">

            <div class="row">
                <div class="col">

                    <div class="featured-boxes">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="featured-box featured-box-primary text-left mt-5">
                                    <div class="box-content">
                                        <h4 class="color-primary font-weight-semibold text-4 text-uppercase mb-3">من مشتری ثابت شما هستم</h4>
                                        <form action="/" id="frmSignIn" method="post" class="needs-validation">
                                            <div class="form-row">
                                                <div class="form-group col">
                                                    <label class="font-weight-bold text-dark text-2">نام کاربری یا آدرس ایمیل</label>
                                                    <input type="text" value="" class="form-control form-control-lg text-left" dir="ltr" required>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col">
                                                    <a class="float-right" href="#">(فراموشی رمز عبور؟)</a>
                                                    <label class="font-weight-bold text-dark text-2">رمز عبور</label>
                                                    <input type="password" value="" class="form-control form-control-lg text-left" dir="ltr" required>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-lg-6">
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input" id="rememberme">
                                                        <label class="custom-control-label text-2" for="rememberme">به خاطر سپاری</label>
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <input type="submit" value="ورود" class="btn btn-primary btn-modern float-right" data-loading-text="در حال بارگذاری ...">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="featured-box featured-box-primary text-left mt-5">
                                    <div class="box-content">
                                        <h4 class="color-primary font-weight-semibold text-4 text-uppercase mb-3">یک حساب ثبت کنید</h4>
                                        <form action="/" id="frmSignUp" method="post" class="needs-validation">
                                            <div class="form-row">
                                                <div class="form-group col">
                                                    <label class="font-weight-bold text-dark text-2">آدرس ایمیل</label>
                                                    <input type="text" value="" class="form-control form-control-lg text-left" dir="ltr" required>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-lg-6">
                                                    <label class="font-weight-bold text-dark text-2">رمز عبور</label>
                                                    <input type="password" value="" class="form-control form-control-lg text-left" dir="ltr" required>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label class="font-weight-bold text-dark text-2">تکرار رمز عبور</label>
                                                    <input type="password" value="" class="form-control form-control-lg text-left" dir="ltr" required>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-lg-9">
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input" id="terms">
                                                        <label class="custom-control-label text-2" for="terms">من <a href="#">قوانین و مقررات</a> را خوانده و موافقم</label>
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-3">
                                                    <input type="submit" value="ثبت نام" class="btn btn-primary btn-modern float-right" data-loading-text="در حال بارگذاری ...">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>

    </div>
@endsection
