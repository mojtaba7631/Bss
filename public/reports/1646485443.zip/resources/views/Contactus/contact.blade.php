@extends('Layout.index')
@section('title',"تماس با ما");
@section('content')
    <div role="main" class="main">

        <section class="page-header page-header-modern bg-color-dark page-header-md">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 order-1 order-md-2 align-self-center">
                        <h1 class="mb-n2 mb-md-0">تماس با ما </h1>

                    </div>
                    <div class="col-md-8 order-2 order-md-1 align-self-center p-static">
                        <ul class="breadcrumb d-block text-md-left breadcrumb-light mb-1 mb-md-0">
                            <li><a href="/">خانه</a></li>
                            <li class="active">تماس با ما</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <div class="container py-4">

            <div class="row mb-5">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <form class="contact-form-recaptcha-v3" action="php/contact-form-recaptcha-v3.php" method="POST">
                        <div class="contact-form-success alert alert-success d-none mt-4">
                            <strong>موفقیت!</strong> پیام شما به ما ارسال شد.
                        </div>

                        <div class="contact-form-error alert alert-danger d-none mt-4">
                            <strong>خطا!</strong> خطایی در ارسال پیام شما پیش آمد.
                            <span class="mail-error-message text-1 d-block"></span>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="required font-weight-bold text-dark text-2" style="color: #daa520 !important;">نام کامل</label>
                                <input type="text" value="" data-msg-required="لطفا نام خود را وارد کنید." maxlength="100" class="form-control" name="name" required>
                            </div>
                            <div class="form-group col-lg-6">
                                <label class="required font-weight-bold text-dark text-2" style="color: #daa520 !important;">آدرس ایمیل</label>
                                <input type="email" value="" data-msg-required="لطفا آدرس ایمیل خود را وارد کنید." data-msg-email="لطفا یک آدرس ایمیل معتبر وارد کنید." maxlength="100" class="form-control text-left" name="email" dir="ltr" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col">
                                <label class="font-weight-bold text-dark text-2" style="color: #daa520 !important;">موضوع</label>
                                <input type="text" value="" data-msg-required="لطفا موضوع را وارد کنید." maxlength="100" class="form-control" name="subject" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col">
                                <label class="required font-weight-bold text-dark text-2" style="color: #daa520 !important;">پیام</label>
                                <textarea maxlength="5000" data-msg-required="لطفا پیام خود را وارد کنید." rows="5" class="form-control" name="message" required></textarea>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col">
                                <input type="submit" value="ارسال پیام" class="btn btn-primary btn-modern" data-loading-text="در حال بارگذاری ...">
                            </div>
                        </div>
                    </form>

                </div>
                <div class="col-md-3"></div>
            </div>
            <div class="row mb-5">
                <div class="col-lg-4">

                    <div class="overflow-hidden mb-3">
                        <h4 class="pt-5 mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="200" data-plugin-options="{'accY': -200}"><strong>ارتباط</strong> با ما</h4>
                    </div>
                    <div class="overflow-hidden mb-3">
                        <p class="lead text-1rem mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="400" data-plugin-options="{'accY': -200}">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است.</p>
                    </div>
                    <div class="overflow-hidden">
                        <p class="mb-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="600" data-plugin-options="{'accY': -200}">لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و</p>
                    </div>

                </div>
                <div class="col-lg-4 offset-lg-1 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="800" data-plugin-options="{'accY': -200}">

                    <h4 class="pt-5"><strong>دفتر</strong> ما</h4>
                    <ul class="list list-icons list-icons-style-3 mt-2">
                        <li class="line-height-9"><i class="fas fa-map-marker-alt top-6"></i> <strong>آدرس:</strong> فلکه دانشگاه، برج بلور، طبقه 345</li>
                        <li class="line-height-9"><i class="fas fa-phone top-6"></i> <strong>تلفن:</strong> <span class="ltr-text">(123) 456-789</span></li>
                        <li class="line-height-9"><i class="fas fa-envelope top-6"></i> <strong>ایمیل:</strong> <a href="mailto:mail@example.com">mail@example.com</a></li>
                    </ul>

                </div>
                <div class="col-lg-3 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="1000" data-plugin-options="{'accY': -200}">

                    <h4 class="pt-5"><strong>ساعات</strong> کاری</h4>
                    <ul class="list list-icons list-dark mt-2">
                        <li><i class="far fa-clock top-6"></i> شنبه تا چهارشنبه - 9 ق.ظ تا 5 ب.ظ</li>
                        <li><i class="far fa-clock top-6"></i> پنج‌شنبه - 9 ق.ظ تا 2 ب.ظ</li>
                        <li><i class="far fa-clock top-6"></i> جمعه - تعطیل</li>
                    </ul>

                </div>
            </div>

        </div>

        <!-- Google Maps - Go to the bottom of the page to change settings and map location. -->
        <div id="googlemaps" class="google-map m-0 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="300" style="height:450px;"></div>

    </div>
@endsection
