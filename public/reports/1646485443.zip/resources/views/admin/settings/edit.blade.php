@extends('Layout.admin_index')
@section('title',"ویرایش تنظیمات")
@section('content')
    <div class="row">
        <div class="container">
            <div class="card">
                <div class="card-header">اضافه کردن تنظیمات</div>
                <div class="card-body">
                    <form method="post">
                        @csrf
                        <div class="row">
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="tell1">تلفن اول</label>
                                    <input type="text" id="tell1" value="{{$settings->tell1}}" name="tell1" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="tell2">تلفن دوم</label>
                                    <input type="text" id="tell2" value="{{$settings->tell2}}" name="tell2" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="email">ایمیل</label>
                                    <input type="text" id="email" value="{{$settings->email}}" name="email" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="map">نقشه</label>
                                    <input type="text" id="map" name="map" class="form-control" value="{{$settings->map}}">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="description">آدرس</label>
                                    <textarea name="description" id="description" class="form-control">{{$settings->address}}</textarea>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-success">ثبت تنظیمات</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
