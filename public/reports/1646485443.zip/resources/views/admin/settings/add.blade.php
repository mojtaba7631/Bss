@extends('Layout.admin_index')
@section('title',"پنل اضافه کردن تنظیمات")
@section('content')
    <div class="row">
        <div class="container">
            <div class="card">
                <div class="card-header">اضافه کردن تنظیمات</div>
                <div class="card-body">
                    <form method="post">
                        @csrf
                        <div class="row">
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="tell1">تلفن اول</label>
                                    <input type="text" id="tell1" name="tell1" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="tell2">تلفن دوم</label>
                                    <input type="text" id="tell2" name="tell2" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="email">ایمیل</label>
                                    <input type="text" id="email" name="email" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="map">نقشه</label>
                                    <input type="text" id="map" name="map" class="form-control">

                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="address">آدرس</label>
                                    <textarea name="address" id="address" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-success">ثبت تنظیمات</button>
                        <a href="{{url('admin/settings')}}" class="btn btn-sm btn-gradient">بازگشت به تنظیمات</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
