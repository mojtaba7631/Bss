<div id="left-sidebar" class="sidebar">
    <div class="navbar-brand">
        <a href="/"><img src="{{asset('admin/assets/images/icon_g.svg')}}" alt="Oculux Logo" class="img-fluid logo"><span>نوپیا</span></a>
        <button type="button" class="btn-toggle-offcanvas btn btn-sm float-right"><i class="lnr lnr-menu icon-close"></i></button>
    </div>
    <div class="sidebar-scroll">
        <div class="user-account">
            <div class="user_div">
                <img src="{{asset('admin/assets/images/user.png')}}" class="user-photo" alt="User Profile Picture">
            </div>
            <div class="dropdown">
                <span>خوش آمدی،</span>
                <a href="javascript:void(0);" class="dropdown-toggle user-name" data-toggle="dropdown"><strong>test</strong></a>
{{--                {{Auth::user()->name}} {{Auth::user()->family}}--}}
                <ul class="dropdown-menu dropdown-menu-right account vivify flipInY">
                    <li><a href="page-profile.html"><i class="icon-user"></i>پروفایل من</a></li>
                    <li><a href="app-inbox.html"><i class="icon-envelope-open"></i>پیام ها</a></li>
                    <li><a href="javascript:void(0);"><i class="icon-settings"></i>تنظیمات</a></li>
                    <li class="divider"></li>
                    <li><a href="page-login.html"><i class="icon-power"></i>خروج</a></li>
                </ul>
            </div>
        </div>
        <nav id="left-sidebar-nav" class="sidebar-nav">
            <ul id="main-menu" class="metismenu">
                <li class="header">اصلی</li>
                <li class="active open">
                    <a href="#myPage" class="has-arrow"><i class="icon-home"></i><span>صفحه من</span></a>
                    <ul>
                        <li class="active"><a href="{{route('panel')}}">داشبورد من</a></li>
                        <li><a href="{{route('users')}}">کاربران</a></li>
                        <li><a href="{{route('admin_new_index')}}">اخبار</a></li>
                        <li><a href="{{route('admin_category_index')}}">دسته بندی اخبار</a></li>
                        <li><a href="{{route('admin_event_index')}}">رویدادها</a></li>
{{--                        <li><a href="{{route('admin_event_speaker')}}">سخنرانان رویداد</a></li>--}}
{{--                        <li><a href="{{route('admin_media_index')}}">رسانه</a></li>--}}
                        <li><a href="{{route('admin_about_index')}}">درباره ما</a></li>
                    </ul>
                </li>
                <li><a href="index2.html"><i class="icon-speedometer"></i><span>داشبورد</span></a></li>
                <li><a href="index3.html"><i class="icon-diamond"></i><span>ارز رمزنگاری</span></a></li>
                <li><a href="../hrms/index.html"><i class="icon-rocket"></i><span>سیستم مدیریت</span></a></li>
                <li><a href="../landing/index.html"><i class="icon-cursor"></i><span>صفحه لندینگ</span></a></li>
                <li class="header">برنامه</li>
                <li>
                    <a href="#Contact" class="has-arrow"><i class="icon-book-open"></i><span>تماس</span></a>
                    <ul>
                        <li><a href="app-contact.html">نمایش لیست</a></li>
                        <li><a href="app-contact2.html">نمایش گرید</a></li>
                    </ul>
                </li>
                <li><a href="app-inbox.html"><i class="icon-envelope"></i><span>ایمیل</span></a></li>
                <li><a href="app-chat.html"><i class="icon-bubbles"></i><span>پیام رسان</span></a></li>
                <li>
                    <a href="#Project" class="has-arrow"><i class="icon-bubbles"></i><span>پروژه</span></a>
                    <ul>
                        <li><a href="app-taskboard.html">نوار وظیفه</a></li>
                        <li><a href="app-project-list.html">لیست پروژه</a></li>
                        <li><a href="app-ticket.html">لیست تیکت</a></li>
                        <li><a href="app-ticket-details.html">جزئیات تیکت</a></li>
                        <li><a href="app-clients.html">مشتریان</a></li>
                        <li><a href="app-todo.html">لیست انجام کار</a></li>
                    </ul>
                </li>
                <li><a href="app-calendar.html"><i class="icon-calendar"></i><span>تقویم</span></a></li>
                <li class="header">عناصر رابط کاربری</li>
                <li>
                    <a href="#uiIcons" class="has-arrow"><i class="icon-tag"></i><span>آیکون ها</span></a>
                    <ul>
                        <li><a href="ui-icons.html">فونت Awesome</a></li>
                        <li><a href="ui-icons-line.html">خط ساده</a></li>
                        <li><a href="ui-icons-themify.html">آیکون Themify</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#uiComponents" class="has-arrow"><i class="icon-diamond"></i><span>کامپونت ها</span></a>
                    <ul>
                        <li><a href="ui-bootstrap.html">رابط بوت استرپ</a></li>
                        <li><a href="ui-typography.html">تایپوگرافی</a></li>
                        <li><a href="ui-colors.html">رنگ ها</a></li>
                        <li><a href="ui-buttons.html">دکمه ها</a></li>
                        <li><a href="ui-tabs.html">زبانه ها</a></li>
                        <li><a href="ui-progressbars.html">نوارهای پیشرفت</a></li>
                        <li><a href="ui-modals.html">مودال ها</a></li>
                        <li><a href="ui-notifications.html">اطلاعیه ها</a></li>
                        <li><a href="ui-dialogs.html">گفتگوها</a></li>
                        <li><a href="ui-list-group.html">فهرست گروه</a></li>
                        <li><a href="ui-media-object.html">شیء رسانه</a></li>
                        <li><a href="ui-nestable.html">تو در تو</a></li>
                        <li><a href="ui-range-sliders.html">اسلایدر محدوده</a></li>
                        <li><a href="ui-helper-class.html">کلاس های کمکی</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#forms" class="has-arrow"><i class="icon-pencil"></i><span>فرم ها</span></a>
                    <ul>
                        <li><a href="forms-basic.html">عناصر پایه</a></li>
                        <li><a href="forms-advanced.html">عناصر پیشرفته</a></li>
                        <li><a href="forms-validation.html">فرم اعتبارسنجی</a></li>
                        <li><a href="forms-wizard.html">فرم پیشرفته</a></li>
                        <li><a href="forms-summernote.html">سامر نوت</a></li>
                        <li><a href="forms-dragdropupload.html">کشیدن و رها کردن آپلود</a></li>
                        <li><a href="forms-editors.html">ویرایشگر کد</a></li>
                        <li><a href="forms-markdown.html">نشانه گذاری</a></li>
                        <li><a href="forms-cropping.html">بریدن تصویر</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#Tables" class="has-arrow"><i class="icon-layers"></i><span>جداول</span></a>
                    <ul>
                        <li><a href="table-normal.html">جداول معمولی</a></li>
                        <li><a href="table-color.html">رنگ جداول</a></li>
                        <li><a href="table-jquery-datatable.html">پایگاه داده جی کوئری</a></li>
                        <li><a href="table-editable.html">جداول قابل ویرایش</a></li>
                        <li><a href="table-filter.html">فیلتر جدول</a></li>
                        <li><a href="table-dragger.html">جدول کشیدن</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#charts" class="has-arrow"><i class="icon-pie-chart"></i><span>نمودارها</span></a>
                    <ul>
                        <li><a href="chart-c3.html">نمودار C3</a></li>
                        <li><a href="chart-chartjs.html">نمودار JS</a></li>
                        <li><a href="chart-morris.html">نمودار موریس</a></li>
                        <li><a href="chart-flot.html">نمودار فلوت</a></li>
                        <li><a href="chart-sparkline.html">نمودار اسپارک لاین</a></li>
                        <li><a href="chart-jquery-knob.html">جی کوئری</a></li>
                    </ul>
                </li>
                <li><a href="map-jvectormap.html"><i class="icon-map"></i><span>نقشه جی وکتور</span></a></li>
                <li class="header">اضافی</li>
                <li><a href="widgets.html"><i class="icon-puzzle"></i><span>ابزارک ها</span></a></li>
                <li>
                    <a href="#Authentication" class="has-arrow"><i class="icon-lock"></i><span>احراز هویت</span></a>
                    <ul>
                        <li><a href="page-login.html">ورود</a></li>
                        <li><a href="page-login2.html">ورود نسخه2</a></li>
                        <li><a href="page-register.html">ثبت نام</a></li>
                        <li><a href="page-forgot-password.html">فراموشی رمزعبور</a></li>
                        <li><a href="page-404.html">صفحه 404</a></li>
                        <li><a href="page-maintenance.html">نگهداری سایت</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#Pages" class="has-arrow"><i class="icon-docs"></i><span>صفحات</span></a>
                    <ul>
                        <li><a href="page-blank.html">صفحه خالی</a></li>
                        <li><a href="page-profile.html">پروفایل کاربر</a></li>
                        <li><a href="page-user-list.html">لیست کاربر</a></li>
                        <li><a href="page-testimonials.html">مشتریان</a></li>
                        <li><a href="page-invoices.html">صورتحساب</a></li>
                        <li><a href="page-timeline.html">خط زمانی</a></li>
                        <li><a href="page-search-results.html">نتیجه جستجوs</a></li>
                        <li><a href="page-gallery.html">گالری تصویر</a></li>
                        <li><a href="page-pricing.html">قیمت گذاری</a></li>
                        <li><a href="page-coming-soon.html">به زودی</a></li>
                    </ul>
                </li>
                <li><a href="../documentation/index.html"><i class="icon-doc"></i><span>مستندات</span></a></li>
            </ul>
        </nav>
    </div>
</div>
