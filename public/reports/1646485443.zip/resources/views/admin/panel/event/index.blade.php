@extends('admin.panel.layout')
@section('title','رویدادها')
@section('content')
    <div id="main-content">
        <div class="container-fluid">
            <div class="block-header">
                <div class="row clearfix">
                    <div class="col-md-6 col-sm-12">
                        <h1>رویدادها</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">نوپیا</a></li>
                                <li class="breadcrumb-item active" aria-current="page">رویدادها</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-md-6 col-sm-12 text-right hidden-xs">
                        <a href="{{url('admin/panel/event/add/')}}" class="btn btn-sm btn-primary" title="">افزودن رویداد</a>
                    </div>
                </div>
            </div>
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="tab-content mt-0">
                            <div class="tab-pane show active" id="Users">
                                <div class="table-responsive">
                                    <table class="table table-hover table-custom spacing8">
                                        <thead>
                                        <tr>
                                            <th class="w60"></th>
                                            <th>عنوان</th>
                                            <th>نمایش در بنر سایت</th>
                                            <th>تاریخ ایجاد شده</th>
                                            <th class="w100">اقدام</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($events as $event)
                                            <tr>
                                                <td class="width45">
                                                    <img src="{{url($event->image)}}" data-toggle="tooltip" data-placement="top" title="نام آواتار" alt="Avatar" class="w35 h35 rounded">
                                                </td>
                                                <td>
                                                    <h6 class="mb-0">{{$event->title}}</h6>
                                                    <span>{{mb_substr(strip_tags($event->meta_description),0,30,mb_detect_encoding($event->meta_description)).'...' }}</span>
                                                </td>
                                                <td>{{ $event->show_site == 0  ? "عدم نمایش در بنر" : "نمایش در بنر" }}</td>
                                                <td>25 اسفند 1397</td>
                                                <td>
                                                    <a href="{{url('admin/panel/event/edit/' . $event->id)}}" style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-edit"></i></a>
                                                    <a href="{{url('admin/panel/event/speaker/' . $event->id)}}" style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-users"></i></a>
                                                    <a href="{{url('admin/panel/event/media/' . $event->id)}}" style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-image"></i></a>
                                                    <a href="{{url('admin/panel/event/delete/' . $event->id)}}" style="padding: 7px;display: inline-grid;border:1px solid #DDDDDD;border-radius: 4px;">
                                                        <i class="fa fa-trash-o text-danger"></i></a>
                                                </td>
                                            </tr>
                                            @endforeach


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
