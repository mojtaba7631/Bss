@extends('admin.panel.layout')
@section('title','افزودن سخنرانان')
@section('style')
    <style>
        .multiselect-container li{
            text-align: right;
        }
        .demo-card label{ display: block; position: relative;}
        .demo-card .col-lg-4{ margin-bottom: 30px;}
    </style>
@endsection
@section('content')
    <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h1>سخنرانان</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">نوپیا</a></li>
                            <li class="breadcrumb-item active" aria-current="page"> افزودن سخنران به رویداد {{ $event->title }}</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-md-6 col-sm-12 text-right hidden-xs">
                    <a href="{{url('admin/panel/speaker/')}}" class="btn btn-sm btn-outline-danger" title="">بازگشت به سخنرانان</a>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>افزودن سخنرانان</h2>
                        <ul class="header-dropdown dropdown">

                            <li><a href="javascript:void(0);" class="full-screen"><i class="icon-frame"></i></a></li>
                            <li class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"></a>
                                <ul class="dropdown-menu">
                                    <li><a href="javascript:void(0);">اقدام</a></li>
                                    <li><a href="javascript:void(0);">دیگر اقدام</a></li>
                                    <li><a href="javascript:void(0);">یک چیز دیگر</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="body wizard_validation">
                        <form id="wizard_with_validation" method="POST" enctype="multipart/form-data">
                            @csrf
                            <fieldset>
                                <div class="row clearfix">
                                    <div class="col-lg-4 col-md-12">
                                        <div class="form-group">
                                            <label>نام</label>
                                            <input type="text" class="form-control" placeholder="نام*" name="name" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                        <div class="form-group">
                                            <label>نام خانوادگی</label>
                                            <input type="text" class="form-control" placeholder=" نام خانوادگی *" name="family" id="family" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                        <div class="form-group">
                                            <label>سمت</label>
                                            <input type="text" class="form-control" placeholder=" سمت *" name="post" id="post" >
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset>
                                <div class="row clearfix">

                                    <div class="col-md-6">
                                        <div class="header">
                                            <h2>محدودیت فایل<small  style="color: red">لطفا فقط png یا jpg را آپلود کنید</small></h2>
                                        </div>
                                        <div class="body">
                                            <input type="file" name="image" class="dropify" data-allowed-file-extensions="jpg png gif jpeg">
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <label>مدرک تحصیلی</label>
                                        <div class="multiselect_div" style="direction: rtl">
                                            <select id="multiselect1" name="evidence" class="multiselect" multiple="multiple" style="direction: rtl">
                                                <option>لطفا مدرک خود را انتخاب کنید</option>
                                                    <option value="8" class="badge badge-danger">فوق دکتری</option>
                                                    <option value="7" class="badge badge-danger">دکتری</option>
                                                    <option value="6" class="badge badge-danger">کارشناسی ارشد</option>
                                                    <option value="5" class="badge badge-danger">کارشناسی</option>
                                                    <option value="4" class="badge badge-danger">فوق دیپلم</option>
                                                    <option value="3" class="badge badge-danger">دیپلم</option>
                                                    <option value="2" class="badge badge-danger">حوزوی</option>
                                                    <option value="1" class="badge badge-danger">سیکل</option>
                                                    <option value="0" class="badge badge-danger">بیسواد</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div>
                                        <input type="submit" class="btn btn-success" value="ثبت سخنران">
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
