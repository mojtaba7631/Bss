@extends('Layout.admin_index')
@section('title',$media->title);
@section('content')
    <div class="row">
        <div class="container mt-5">
            <div class="card">
                <div class="card-header" >{{$media->title}}</div>
                <div class="card-body" >
                    {{ $media->description }}
                    <hr>
                    @if($media->images()->count() > 0)
                        <div class="row">
                            @foreach ($media->images()->get() as $image)
                                <div class="col-md-4">
                                    <div class="card mt-3" >
                                        <div class="card-header">{{ $image->title }}</div>
                                        <div class="card-body">
                                            <img src="{{ url($image->path) }}" class="w-100 thumbnail img" alt="" style="height: 160px">
                                        </div>
                                        <div class="card-footer">
                                            <a href="{{ url('admin/media/remove_image/' . $image->id) }}" class="btn btn-danger">حذف</a>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                    @else
                        <div class="alert alert-info">عکسی آپلود نشده است.</div>
                    @endif
                </div>
            </div>
            <div class="card mt-2">
                <div class="card-header">افزودن فایل رسانه</div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data" action="{{ url('admin/panel/media/add_image/' . $media->id) }}">
                        @csrf
                        <div class="form-group">
                            <label for="file">فایل</label>
                            <input type="file" id="file" name="file" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="title">عنوان</label>
                            <input type="text" id="title" name="title" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="slug">نامک</label>
                            <input type="text" id="slug" name="slug" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="description">توضیحات</label>
                            <textarea id="description" name="description" class="form-control"></textarea>
                        </div>

                        <input type="submit" value="ذخیره فایل" class="btn btn-default">
                        <a href="{{url('admin/media')}}" class="btn btn-default">برگشت به رسانه</a>

                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
