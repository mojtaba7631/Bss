@extends('admin.panel.layout')
@section('title','افزودن دسته')
@section('style')
    <style>
        .multiselect-container li{
            text-align: right;
        }
        .demo-card label{ display: block; position: relative;}
        .demo-card .col-lg-4{ margin-bottom: 30px;}
    </style>
@endsection
@section('content')
    <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h1>دسته بندی</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">نوپیا</a></li>
                            <li class="breadcrumb-item active" aria-current="page">افزودن دسته</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-md-6 col-sm-12 text-right hidden-xs">
                    <a href="{{url('admin/panel/category/')}}" class="btn btn-sm btn-outline-danger" title="">بازگشت به دسته بندی</a>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="card">
                    <div class="header">
                        <h2>افزودن دسته</h2>
                        <ul class="header-dropdown dropdown">

                            <li><a href="javascript:void(0);" class="full-screen"><i class="icon-frame"></i></a></li>
                            <li class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"></a>
                                <ul class="dropdown-menu">
                                    <li><a href="javascript:void(0);">اقدام</a></li>
                                    <li><a href="javascript:void(0);">دیگر اقدام</a></li>
                                    <li><a href="javascript:void(0);">یک چیز دیگر</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="body wizard_validation">
                        <form id="wizard_with_validation" method="POST" enctype="multipart/form-data">
                            @csrf
                            <fieldset>
                                <div class="row clearfix">
                                    <div class="col-lg-6 col-md-12">
                                        <div class="form-group">
                                            <label>عنوان</label>
                                            <input type="text" class="form-control" placeholder="عنوان دسته *" name="title" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-12">
                                        <div class="form-group">
                                            <label>نامک</label>
                                            <input type="text" class="form-control" placeholder="نامک دسته *" name="slug" id="slug" required>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                            <fieldset>
                                <div class="row clearfix">

                                    <div class="col-12">
                                        <label>توضیح دسته</label>
                                        <textarea class="summernote" name="description"></textarea>
                                    </div>
                                    <div>
                                        <input type="submit" class="btn btn-success" value="ثبت دسته">
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
