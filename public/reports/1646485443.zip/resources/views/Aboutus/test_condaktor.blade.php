@extends('Layout.admin_index')
@section('title',"ویرایش مدیا")
@section('content')
    <div class="row">
        <div class="container">
            <div class="card">
                <div class="card-header">ویرایش مدیا</div>
                <div class="card-body">
                    <form method="post">
                        @csrf

                        <div class="row">
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="title">عنوان</label>
                                    <input type="text" id="title" value="{{$media->title}}" name="title" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="from-group mb-3">
                                    <label for="url">نامک</label>
                                    <input type="text" id="url" value="{{$media->slug}}" name="url" class="form-control">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="description">توضیحات</label>
                                    <textarea name="description" id="description" class="form-control">
                                        {{$media->description}}
                                    </textarea>
                                </div>
                            </div>
                        </div>




                        <hr>
                        <button type="submit" class="btn btn-success">ثبت مدیا</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
