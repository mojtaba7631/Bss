@extends('Layout.index')
@section('title',"درباره ما");
@section('content')
    <div role="main" class="main">

        <section class="page-header page-header-modern bg-color-dark page-header-md">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 order-1 order-md-2 align-self-center">
                        <h1 class="mb-n2 mb-md-0">درباره ما </h1>

                    </div>
                    <div class="col-md-8 order-2 order-md-1 align-self-center p-static">
                        <ul class="breadcrumb d-block text-md-left breadcrumb-light mb-1 mb-md-0">
                            <li><a href="/">خانه</a></li>
                            <li class="active">درباره ما</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <div class="container pb-1">

            <div class="row pt-4">
                <div class="col">
                    <div class="overflow-hidden mb-3">
                        <h2 class="word-rotator slide font-weight-bold text-7 text-sm-8 mb-0 appear-animation" data-appear-animation="maskUp">
                            <span>راهی جدید برای </span>
                            <span class="word-rotator-words bg-primary">
										<b class="is-visible">موفقیت</b>
										<b>نوآوری</b>
										<b>پیشرفت</b>
									</span>
                        </h2>
                    </div>
                </div>
            </div>
        </div>
        <section class="section section-default border-0 my-5 appear-animation" data-appear-animation="fadeIn" data-appear-animation-delay="750">
            <div class="container py-4">

                <div class="row align-items-center">
                    <div class="col-md-6 appear-animation" data-appear-animation="fadeInLeftShorter" data-appear-animation-delay="1000">
                        <div class="owl-carousel owl-theme nav-inside mb-0" data-plugin-options="{'items': 1, 'margin': 10, 'animateOut': 'fadeOut', 'autoplay': true, 'autoplayTimeout': 6000, 'loop': true}">
                            <div>
                                <img alt="" class="img-fluid" src="{{$f_image}}">
                            </div>
                            <div>
                                <img alt="" class="img-fluid" src="{{$s_image}}">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="overflow-hidden mb-2">
                            <h2 class="font-weight-normal text-5 mb-0 pt-0 mt-0 appear-animation" data-appear-animation="maskUp" data-appear-animation-delay="1200"><strong class="font-weight-extra-bold" style="color: #000">معرفی</strong> ما</h2>
                        </div>
                        <p class="appear-animation text-justify" data-appear-animation="fadeInUpShorter" data-appear-animation-delay="1400">
                            {!! $introducing_us !!}
                        </p>
                    </div>
                </div>

            </div>
        </section>

        <div class="container">

            <div class="row mt-5 py-3">
                <div class="col-md-6">
                    <div class="toggle toggle-primary toggle-simple m-0" data-plugin-toggle>
                        <section class="toggle active mt-0">
                            <a class="toggle-title">چشم انداز ما</a>
                            <div class="toggle-content">
                                <p>{!! $our_vision !!}</p>
                            </div>
                        </section>
                        <section class="toggle">
                            <a class="toggle-title">ماموریت ما</a>
                            <div class="toggle-content">
                                <p>{!! $our_mission !!}</p>
                            </div>
                        </section>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="progress-bars mt-5 mt-md-0">
                        <div class="progress-label mb-1">
                            <span class="text-1">{{$progress_bar_name1}}</span>
                        </div>
                        <div class="progress mb-2">
                            <div class="progress-bar progress-bar-primary" data-appear-progress-animation="100%">
                                <span class="progress-bar-tooltip">{{$progress_bar_cent1}}</span>
                            </div>
                        </div>
                        <div class="progress-label mb-1">
                            <span class="text-1">{{$progress_bar_name2}}</span>
                        </div>
                        <div class="progress mb-2">
                            <div class="progress-bar progress-bar-primary" data-appear-progress-animation="85%" data-appear-animation-delay="300">
                                <span class="progress-bar-tooltip">{{$progress_bar_cent2}}</span>
                            </div>
                        </div>
                        <div class="progress-label mb-1">
                            <span class="text-1">{{$progress_bar_name3}}</span>
                        </div>
                        <div class="progress mb-2">
                            <div class="progress-bar progress-bar-primary" data-appear-progress-animation="75%" data-appear-animation-delay="600">
                                <span class="progress-bar-tooltip">{{$progress_bar_cent3}}</span>
                            </div>
                        </div>
                        <div class="progress-label mb-1">
                            <span class="text-1">{{$progress_bar_name4}}</span>
                        </div>
                        <div class="progress mb-2">
                            <div class="progress-bar progress-bar-primary" data-appear-progress-animation="85%" data-appear-animation-delay="900">
                                <span class="progress-bar-tooltip">{{$progress_bar_cent4}}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col py-4">
                    <hr class="solid">
                </div>
            </div>


        </div>
    </div>
@endsection
